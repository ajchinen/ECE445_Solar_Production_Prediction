# UH Mānoa Campus Grid — Load Forecasting Project
## EE / Data Science Capstone · FY2025

---

## What This Project Does

Forecasts the **24-hour load profile** (kW demand by hour) of the UH Mānoa
campus electrical grid using historical substation meter data and weather.

**Input:**  Projected weather for a future day  
**Output:** A predicted load curve — 24 hourly kW values

---

## Project Structure

```
uh_forecast/
├── substation_totalized_kw_15_min_fy25.csv   ← your meter data
│
├── step1_pipeline.py     Load meter + fetch weather → daily profiles
├── step2_features.py     Build lag features + train/test split
├── step3_train.py        Train 4 models + evaluate
├── step4_visualize.py    Generate all plots
├── step5_forecast.py     Forecast a future date
│
└── README.md             This file
```

---

## Setup

```bash
# Create a virtual environment (recommended)
python -m venv venv
source venv/bin/activate          # Mac/Linux
venv\Scripts\activate             # Windows

# Install all dependencies
pip install pandas numpy matplotlib seaborn scikit-learn xgboost \
            openmeteo-requests requests-cache retry-requests \
            scipy optuna pickle5
```

---

## Run Order

Run the steps **in order**. Each step saves CSV/pickle files that the
next step reads.

### Step 1 — Data Pipeline  (~2–5 min, mostly waiting on weather API)
```bash
python step1_pipeline.py
```
Outputs: `profiles.csv`, `daily_features.csv`, `hourly_merged.csv`

### Step 2 — Feature Engineering  (<1 min)
```bash
python step2_features.py
```
Outputs: `X_train.csv`, `X_test.csv`, `Y_train.csv`, `Y_test.csv`

### Step 3 — Train Models  (~3–8 min)
```bash
python step3_train.py
```
Outputs: `xgb_models.pkl`, `predictions_*.csv`, `model_comparison.csv`

### Step 4 — Visualizations  (<1 min)
```bash
python step4_visualize.py
```
Outputs: 7 PNG plot files

### Step 5 — Forecast a Future Date  (<1 min)
```bash
# Forecast tomorrow (default)
python step5_forecast.py

# Forecast a specific date (must be within next 7 days)
python step5_forecast.py --date 2025-06-15
```
Output: `forecast_YYYY-MM-DD.png`

---

## Your Data

| Field       | Detail |
|-------------|--------|
| File        | `substation_totalized_kw_15_min_fy25.csv` |
| Meter ID    | 88162154 (UH Mānoa main substation) |
| Period      | July 1 2024 – June 30 2025 (full FY25) |
| Interval    | 15 minutes (35,040 rows) |
| Columns     | `datetime`, `kw`, `kvar`, `kva`, `pf` |
| kW range    | 7,893 – 16,440 kW |
| kW mean     | 11,337 kW |

The `kw` column is **already instantaneous power demand** — no conversion needed.

---

## Weather Source

**Open-Meteo** (https://open-meteo.com) — free, no API key, ERA5 reanalysis.  
Coordinates used: 21.2969°N, 157.8171°W (UH Mānoa campus)

Weather variables fetched:
- `temp_f` — Air temperature (°F)
- `humidity_pct` — Relative humidity (%)
- `dew_point_f` — Dew point temperature (°F)
- `solar_wm2` — Shortwave radiation / solar irradiance (W/m²)
- `wind_mph` — Wind speed at 10m (mph)
- `cloud_pct` — Cloud cover (%)
- `precip_mm` — Precipitation (mm)
- `et0_mm` — FAO reference evapotranspiration (combined heat stress index)

---

## Models

| Model | Description | Expected MAE |
|-------|-------------|--------------|
| Persistence | Tomorrow = yesterday | ~600–900 kW |
| Mean Profile | Average by day-of-week | ~400–600 kW |
| Ridge Regression | Linear, all 24 hours | ~250–400 kW |
| **XGBoost** | 24 gradient-boosted tree models | **~150–280 kW** |

---

## Key Features

The XGBoost model uses ~150+ features. The most important ones are:

1. `lag1_h00` … `lag1_h23` — Yesterday's full 24-hour load profile
2. `lag7_h00` … `lag7_h23` — Same weekday last week's profile
3. `cdh_total` — Cooling degree hours (AC demand proxy)
4. `temp_max` — Daily maximum temperature
5. `solar_total` — Total daily solar irradiance
6. `heat_idx_max` — Maximum apparent temperature (temp + humidity effect)
7. `is_weekend`, `day_of_week` — Calendar features
8. `roll7_*` — 7-day rolling average profile

---

## Notes for Your Report

- **Why temporal split?** Random splitting leaks future data into training,
  making results artificially optimistic. We always split by time.
- **Why one XGBoost per hour?** Midnight load and 2pm load are driven by
  different physics. Separate models let each hour learn its own feature weights.
- **Low-load days** — 9 days had min kW < 8,500 (holidays/breaks). These are
  flagged in `step1_pipeline.py` and handled by the `is_holiday` feature.
- **Extending to 15-min resolution** — Replace `resample("h")` with
  `resample("15min")` in step1 and change `24` → `96` throughout.
