"""
step2_features.py
=================
UH Mānoa Campus Grid — Load Forecasting Project
------------------------------------------------
WHAT THIS FILE DOES:
  Reads the outputs from step1_pipeline.py and builds the final
  feature matrix X and target matrix Y that the model will train on.

  Key features added here:
    - Lag profiles (yesterday, same weekday last week)
    - Rolling statistics (7-day average profile)
    - Temporal train/test split (never random — always by time)
    - Optional PCA decomposition of profiles

WHY THESE FEATURES MATTER
--------------------------
Your XGBoost model can only learn from patterns visible in the
feature matrix. Raw weather alone won't capture everything:

  "Yesterday, load was 14,000 kW at 2pm" is extremely informative
  because campus behavior has strong inertia — if yesterday was
  a high-load day, today probably is too (same semester schedule,
  same people, similar activity).

  The 7-day rolling mean captures the "typical week" at this point
  in the semester — finals week looks different from mid-semester.
"""

import pandas as pd
import numpy as np
from sklearn.decomposition import PCA
from sklearn.preprocessing import StandardScaler
import warnings
warnings.filterwarnings("ignore")

HOURS = [f"h{h:02d}" for h in range(24)]


# ══════════════════════════════════════════════════════════════════════════════
# STEP 2A — Build Full Feature Matrix
# ══════════════════════════════════════════════════════════════════════════════

def build_features(profiles: pd.DataFrame,
                   daily_X:  pd.DataFrame) -> tuple[pd.DataFrame, pd.DataFrame]:
    """
    Combine daily weather/calendar features with lag profile features.

    Parameters
    ----------
    profiles : [N_days × 24]   load kW for each hour
    daily_X  : [N_days × feats] weather + calendar summaries

    Returns
    -------
    X : complete feature matrix  [N_valid_days × all_features]
    Y : target profile matrix    [N_valid_days × 24]
    """
    frames = [daily_X.copy()]

    # ── Lag 1: Yesterday's full 24-hour profile ──────────────────────────────
    # This is typically the single most predictive feature group.
    # "What did load look like at each hour yesterday?"
    lag1 = profiles.shift(1)
    lag1.columns = [f"lag1_{c}" for c in HOURS]
    frames.append(lag1)

    # Summary stats of yesterday's profile
    frames.append(pd.DataFrame({
        "lag1_peak_kw"    : lag1.max(axis=1),
        "lag1_mean_kw"    : lag1.mean(axis=1),
        "lag1_min_kw"     : lag1.min(axis=1),
        "lag1_peak_hour"  : lag1.apply(
                              lambda r: float(np.argmax(r.values)) if r.notna().any() else np.nan,
                              axis=1),
        "lag1_daily_kwh"  : lag1.sum(axis=1),  # approx daily energy
    }, index=profiles.index))

    # ── Lag 7: Same weekday last week ────────────────────────────────────────
    # Monday of this week closely resembles Monday of last week
    # because the university schedule repeats weekly.
    lag7 = profiles.shift(7)
    lag7.columns = [f"lag7_{c}" for c in HOURS]
    frames.append(lag7)

    frames.append(pd.DataFrame({
        "lag7_peak_kw"   : lag7.max(axis=1),
        "lag7_mean_kw"   : lag7.mean(axis=1),
        "lag7_daily_kwh" : lag7.sum(axis=1),
    }, index=profiles.index))

    # ── Lag 2: Two days ago ──────────────────────────────────────────────────
    lag2 = profiles.shift(2)
    lag2.columns = [f"lag2_{c}" for c in HOURS]
    frames.append(lag2)

    # ── Rolling 7-day mean profile (excludes today) ──────────────────────────
    # Captures the "typical campus pattern this week."
    # shift(1) ensures we only use past data, not today's.
    roll7 = profiles.shift(1).rolling(window=7, min_periods=3).mean()
    roll7.columns = [f"roll7_{c}" for c in HOURS]
    frames.append(roll7)

    roll7_stats = pd.DataFrame({
        "roll7_peak_kw"  : roll7.max(axis=1),
        "roll7_mean_kw"  : roll7.mean(axis=1),
    }, index=profiles.index)
    frames.append(roll7_stats)

    # ── Rolling 7-day temperature mean (weather trend) ───────────────────────
    frames.append(pd.DataFrame({
        "roll7_temp_mean" : daily_X["temp_mean"].shift(1).rolling(7).mean(),
        "roll7_cdh_mean"  : daily_X["cdh_total"].shift(1).rolling(7).mean(),
    }, index=profiles.index))

    # ── Combine ──────────────────────────────────────────────────────────────
    X = pd.concat(frames, axis=1)
    Y = profiles.copy()

    # Drop first 7 rows — lag7 features are unavailable for those days
    X = X.iloc[7:]
    Y = Y.iloc[7:]

    # Remove any remaining rows with NaN in either X or Y
    valid_X = X.dropna().index
    valid_Y = Y.dropna(how="any").index
    valid   = valid_X.intersection(valid_Y)

    X, Y = X.loc[valid], Y.loc[valid]

    print(f"── Feature matrix built ────────────────────────────────────")
    print(f"  Features : {X.shape[1]}")
    print(f"  Days     : {X.shape[0]}")
    print(f"  Date range: {X.index.min().date()} → {X.index.max().date()}\n")

    return X, Y


# ══════════════════════════════════════════════════════════════════════════════
# STEP 2B — Temporal Train / Test Split
# ══════════════════════════════════════════════════════════════════════════════

def temporal_split(X: pd.DataFrame,
                   Y: pd.DataFrame,
                   test_days: int = 60) -> tuple:
    """
    Reserve the LAST `test_days` days for testing.

    WHY NOT RANDOM SPLIT?
    ----------------------
    A random split lets the model "see" future data during training,
    which makes results look artificially good. In the real world you
    always forecast forward — you never know tomorrow's load today.

    Temporal split = honest evaluation:
        Train: everything up to a cutoff date
        Test : everything after the cutoff

    We use the last 60 days (2 months) as a held-out test set.
    Everything before that is used for training.

    Parameters
    ----------
    test_days : number of most-recent days held out for testing

    Returns
    -------
    X_train, X_test, Y_train, Y_test
    """
    split_idx  = len(X) - test_days
    X_train    = X.iloc[:split_idx]
    X_test     = X.iloc[split_idx:]
    Y_train    = Y.iloc[:split_idx]
    Y_test     = Y.iloc[split_idx:]

    print(f"── Train / Test split ──────────────────────────────────────")
    print(f"  Train : {len(X_train)} days  "
          f"({X_train.index.min().date()} → {X_train.index.max().date()})")
    print(f"  Test  : {len(X_test)} days  "
          f"({X_test.index.min().date()} → {X_test.index.max().date()})\n")

    return X_train, X_test, Y_train, Y_test


# ══════════════════════════════════════════════════════════════════════════════
# STEP 2C — Optional PCA Decomposition
# ══════════════════════════════════════════════════════════════════════════════

class ProfilePCA:
    """
    Compress 24-hour profiles into a small number of "shape components."

    HOW IT WORKS
    ------------
    Imagine plotting all 365 daily load curves on the same graph.
    They don't look totally random — they cluster into a few shapes:
      • High weekday peak (10am–4pm AC surge)
      • Moderate weekday (mild weather day)
      • Low weekend/holiday
      • Ultra-low semester break

    PCA mathematically finds these dominant shapes (called principal
    components or "basis profiles"). Each actual day's curve can then
    be described as a weighted combination of these shapes:

        Day's profile ≈ w1 × shape1 + w2 × shape2 + w3 × shape3

    WHY USE THIS
    ------------
    Instead of predicting 24 numbers (one per hour), your model
    predicts 4–6 weights. This is:
      • Simpler (fewer numbers to predict)
      • Smoother (reconstructed curves can't have wild hour-to-hour spikes)
      • More interpretable (each component has a physical meaning)

    MATH BEHIND IT
    --------------
    PCA runs Singular Value Decomposition (SVD) on your profile matrix Y:
        Y = U × S × Vᵀ
    The rows of Vᵀ are the basis profile shapes.
    U × S gives the per-day coefficients.
    We keep only the top k components.

    Usage
    -----
        pca = ProfilePCA(n_components=6)
        C_train = pca.fit_transform(Y_train)   # [N × 6] coefficients
        Y_reconstructed = pca.inverse_transform(C_pred)  # back to [N × 24]
    """

    def __init__(self, n_components: int = 6):
        self.n   = n_components
        self.pca = PCA(n_components=n_components)
        self.scaler = StandardScaler()

    def fit(self, Y: np.ndarray) -> "ProfilePCA":
        Y_sc = self.scaler.fit_transform(Y)
        self.pca.fit(Y_sc)
        cumvar = self.pca.explained_variance_ratio_.cumsum()
        print(f"── PCA on load profiles ────────────────────────────────────")
        print(f"  Components : {self.n}")
        for i, (ev, cv) in enumerate(
            zip(self.pca.explained_variance_ratio_, cumvar)
        ):
            bar = "█" * int(ev * 200)
            print(f"  PC{i+1}: {ev*100:5.1f}%  cumulative {cv*100:.1f}%  {bar}")
        print()
        return self

    def transform(self, Y: np.ndarray) -> np.ndarray:
        return self.pca.transform(self.scaler.transform(Y))

    def fit_transform(self, Y: np.ndarray) -> np.ndarray:
        return self.fit(Y).transform(Y)

    def inverse_transform(self, C: np.ndarray) -> np.ndarray:
        return self.scaler.inverse_transform(self.pca.inverse_transform(C))

    @property
    def basis_profiles(self) -> pd.DataFrame:
        """The k fundamental load curve shapes [n_components × 24]."""
        profiles = self.scaler.inverse_transform(self.pca.components_)
        return pd.DataFrame(profiles,
                            index   = [f"PC{i+1}" for i in range(self.n)],
                            columns = HOURS)


# ══════════════════════════════════════════════════════════════════════════════
# MAIN
# ══════════════════════════════════════════════════════════════════════════════

if __name__ == "__main__":
    print("=" * 60)
    print(" UH Mānoa Load Forecast — Step 2: Feature Engineering")
    print("=" * 60 + "\n")

    profiles = pd.read_csv("profiles.csv",      index_col=0, parse_dates=True)
    daily_X  = pd.read_csv("daily_features.csv",index_col=0, parse_dates=True)

    # Build features
    X, Y = build_features(profiles, daily_X)

    # Train/test split (last 60 days = test)
    X_train, X_test, Y_train, Y_test = temporal_split(X, Y, test_days=60)

    # Run PCA on training profiles to understand structure
    pca = ProfilePCA(n_components=6)
    pca.fit(Y_train.values)

    # Save splits for Step 3
    X_train.to_csv("X_train.csv")
    X_test.to_csv("X_test.csv")
    Y_train.to_csv("Y_train.csv")
    Y_test.to_csv("Y_test.csv")

    print("── Saved files ─────────────────────────────────────────────")
    print("  X_train.csv / X_test.csv  → feature matrices")
    print("  Y_train.csv / Y_test.csv  → target profile matrices")
    print()
    print("  → Run step3_train.py next")
