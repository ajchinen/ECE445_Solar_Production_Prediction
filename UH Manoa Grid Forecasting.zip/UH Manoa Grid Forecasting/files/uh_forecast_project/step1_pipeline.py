"""
step1_pipeline.py
=================
UH Mānoa Campus Grid — Load Forecasting Project
------------------------------------------------
WHAT THIS FILE DOES:
  1. Loads the 15-min substation meter data (FY25)
  2. Resamples to hourly (averages 4 readings per hour)
  3. Fetches one full year of hourly weather from Open-Meteo (free, no key)
  4. Merges load + weather on timestamp
  5. Reshapes everything into a daily profile matrix [365 days × 24 hours]
  6. Saves two clean CSV files for Step 2 to use

RUN THIS FIRST before any other step.
"""

import pandas as pd
import numpy as np
import openmeteo_requests
import requests_cache
from retry_requests import retry
import warnings
warnings.filterwarnings("ignore")

# ── Configuration ──────────────────────────────────────────────────────────────

METER_CSV   = "substation_totalized_kw_15_min_fy25.csv"
START_DATE  = "2024-07-01"
END_DATE    = "2025-06-30"
CAMPUS_LAT  =  21.2969    # UH Mānoa
CAMPUS_LON  = -157.8171
TIMEZONE    = "Pacific/Honolulu"


# ══════════════════════════════════════════════════════════════════════════════
# STEP 1A — Load & Clean Meter Data
# ══════════════════════════════════════════════════════════════════════════════

def load_meter(filepath: str) -> pd.Series:
    """
    Load the 15-min substation CSV and resample to hourly.

    The kw column is already instantaneous power demand — no
    conversion from cumulative energy is needed (unlike a totalized
    kWh meter). We just average the four 15-min readings per hour.

    Returns
    -------
    pd.Series  indexed by hourly timestamp, values in kW
    """
    print("── Loading meter data ──────────────────────────────────────")
    df = pd.read_csv(filepath, parse_dates=["datetime"])
    df = df.set_index("datetime").sort_index()

    # Sanity check: confirm 15-min spacing
    gaps = df.index.to_series().diff().dropna()
    expected = pd.Timedelta("15min")
    bad_gaps = gaps[gaps != expected]
    if len(bad_gaps) > 0:
        print(f"  [!] {len(bad_gaps)} irregular intervals found — check your data")
    else:
        print(f"  ✓  {len(df):,} rows, perfectly regular 15-min intervals")

    print(f"  ✓  Date range: {df.index.min().date()} → {df.index.max().date()}")
    print(f"  ✓  kW range  : {df.kw.min():.0f} – {df.kw.max():.0f} kW")
    print(f"  ✓  kW mean   : {df.kw.mean():.0f} kW\n")

    # ── Resample: 15-min → hourly (mean of 4 readings) ──────────────────────
    # We use mean() so units stay in kW (not kWh).
    # If you want to keep 15-min resolution: skip this and use df["kw"] directly.
    hourly_kw = df["kw"].resample("h").mean()

    # ── Flag and interpolate missing hours ───────────────────────────────────
    n_missing = hourly_kw.isna().sum()
    if n_missing > 0:
        print(f"  [!] {n_missing} missing hourly values — interpolating (linear)")
        hourly_kw = hourly_kw.interpolate(method="linear", limit=3)

    return hourly_kw


# ══════════════════════════════════════════════════════════════════════════════
# STEP 1B — Fetch Weather from Open-Meteo
# ══════════════════════════════════════════════════════════════════════════════

def fetch_weather(start: str, end: str,
                  lat: float = CAMPUS_LAT,
                  lon: float = CAMPUS_LON) -> pd.DataFrame:
    """
    Pull hourly historical weather for UH Mānoa from Open-Meteo.

    Open-Meteo uses the ERA5 reanalysis dataset — it reconstructs
    past weather from satellite + ground station data. Free, no API
    key required, and accurate for Hawaiʻi.

    Variables fetched and why each matters for load forecasting
    -----------------------------------------------------------
    temperature_2m      : Primary AC load driver — higher temp = more cooling
    relative_humidity   : Wet-bulb effect — humidity makes cooling harder
    dew_point_2m        : Comfort threshold — humans cool less efficiently
                          above ~65°F dew point; AC works harder
    shortwave_radiation : Solar heat gain through windows drives daytime AC.
                          Also drives on-campus solar generation (duck curve)
    wind_speed_10m      : Wind cooling reduces envelope load slightly
    cloud_cover         : Modifies solar gain and perceived temperature
    precipitation       : Rain → cloud cover → less solar, sometimes less load
    et0_fao_evapotrans  : Combined temp+humidity+solar+wind index (expert feature)

    Returns
    -------
    pd.DataFrame  indexed by hourly timestamp, columns = weather variables
    """
    print("── Fetching weather from Open-Meteo ───────────────────────")
    print(f"  Location : {lat}°N, {lon}°E  (UH Mānoa)")
    print(f"  Period   : {start} → {end}")

    # Cache responses locally so re-runs don't re-fetch (saves time)
    cache   = requests_cache.CachedSession(".weather_cache", expire_after=-1)
    session = retry(cache, retries=5, backoff_factor=0.3)
    om      = openmeteo_requests.Client(session=session)

    params = {
        "latitude":        lat,
        "longitude":       lon,
        "start_date":      start,
        "end_date":        end,
        "hourly": [
            "temperature_2m",
            "relative_humidity_2m",
            "dew_point_2m",
            "shortwave_radiation",
            "wind_speed_10m",
            "cloud_cover",
            "precipitation",
            "et0_fao_evapotranspiration",
        ],
        "temperature_unit": "fahrenheit",
        "wind_speed_unit":  "mph",
        "timezone":          TIMEZONE,
    }

    resp   = om.weather_api("https://archive-api.open-meteo.com/v1/archive",
                             params=params)[0]
    hourly = resp.Hourly()

    col_names = [
        "temp_f", "humidity_pct", "dew_point_f",
        "solar_wm2", "wind_mph", "cloud_pct",
        "precip_mm", "et0_mm",
    ]

    timestamps = pd.date_range(
        start     = pd.to_datetime(hourly.Time(),    unit="s", utc=True),
        end       = pd.to_datetime(hourly.TimeEnd(), unit="s", utc=True),
        freq      = pd.Timedelta(seconds=hourly.Interval()),
        inclusive = "left"
    ).tz_convert(TIMEZONE).tz_localize(None)   # strip tz for clean merging

    weather = pd.DataFrame(
        {name: hourly.Variables(i).ValuesAsNumpy()
         for i, name in enumerate(col_names)},
        index = timestamps
    )

    print(f"  ✓  {len(weather):,} hourly weather records fetched")
    print(f"  ✓  Temp range : {weather.temp_f.min():.1f} – {weather.temp_f.max():.1f} °F")
    print(f"  ✓  Max solar  : {weather.solar_wm2.max():.0f} W/m²\n")

    return weather


# ══════════════════════════════════════════════════════════════════════════════
# STEP 1C — Merge & Add Engineered Weather Features
# ══════════════════════════════════════════════════════════════════════════════

def engineer_weather_features(weather: pd.DataFrame) -> pd.DataFrame:
    """
    Add domain-knowledge features derived from raw weather variables.

    These capture physical relationships that matter for HVAC load:

    Cooling Degree Hours (CDH)
    --------------------------
    CDH = max(0, temp - base_temp)
    Base temperature = 65°F (below this, no mechanical cooling needed).
    CDH is a direct proxy for how hard the AC has to work each hour.
    A day with CDH = 200 means air conditioning ran hard all day.

    Heat Index (Apparent Temperature)
    ----------------------------------
    Humans and thermostats respond to how hot it FEELS, not just dry
    air temperature. High humidity makes 85°F feel like 92°F.
    We use a simplified Rothfusz formula.

    Hour-of-Day Sine/Cosine Encoding
    ----------------------------------
    Hour 23 and hour 0 are neighbors (11pm → midnight), but the number
    23 and 0 are far apart numerically. Encoding as:
        sin(2π × hour/24),  cos(2π × hour/24)
    makes this circular relationship visible to the model.
    """
    w = weather.copy()

    # ── Cooling Degree Hours ────────────────────────────────────────────────
    w["cdh"] = (w["temp_f"] - 65).clip(lower=0)

    # ── Heat Index (Rothfusz simplified) ────────────────────────────────────
    # Only meaningful above 80°F
    T, RH = w["temp_f"], w["humidity_pct"]
    w["heat_index_f"] = (
        -42.379
        + 2.04901523  * T
        + 10.14333127 * RH
        - 0.22475541  * T * RH
        - 0.00683783  * T**2
        - 0.05481717  * RH**2
        + 0.00122874  * T**2 * RH
        + 0.00085282  * T * RH**2
        - 0.00000199  * T**2 * RH**2
    )
    # Clamp to actual temp when below threshold (formula breaks below 80°F)
    w["heat_index_f"] = w[["temp_f", "heat_index_f"]].max(axis=1)

    # ── Hour-of-day circular encoding ───────────────────────────────────────
    hour = w.index.hour
    w["hour_sin"] = np.sin(2 * np.pi * hour / 24)
    w["hour_cos"] = np.cos(2 * np.pi * hour / 24)

    # ── Month circular encoding ──────────────────────────────────────────────
    month = w.index.month
    w["month_sin"] = np.sin(2 * np.pi * month / 12)
    w["month_cos"] = np.cos(2 * np.pi * month / 12)

    return w


def merge(load: pd.Series, weather: pd.DataFrame) -> pd.DataFrame:
    """Inner-join load and weather on timestamp. Report any dropped rows."""
    merged = load.to_frame("kw").join(weather, how="inner")
    print(f"── Merging load + weather ──────────────────────────────────")
    print(f"  Load rows    : {len(load):,}")
    print(f"  Weather rows : {len(weather):,}")
    print(f"  Merged rows  : {len(merged):,}  "
          f"({len(load)-len(merged)} dropped)\n")
    return merged


# ══════════════════════════════════════════════════════════════════════════════
# STEP 1D — Reshape Into Daily Profiles
# ══════════════════════════════════════════════════════════════════════════════

def reshape_profiles(hourly: pd.DataFrame,
                     min_hours: int = 20) -> tuple[pd.DataFrame, pd.DataFrame]:
    """
    Convert hourly merged data into two matrices:

    profiles  : [N_days × 24]  — the kW load at each hour of the day
                This is your MODEL TARGET (what you're trying to predict)

    daily_X   : [N_days × features] — one row of features per day
                This is your MODEL INPUT

    Why reshape?
    ------------
    Your model predicts an entire day's shape at once.
    To do that, the data needs to be organized by day, not by hour.
    A "profile" is just one row = one full 24-hour load curve.

    Parameters
    ----------
    min_hours : minimum valid hours per day (days with fewer are dropped)

    Returns
    -------
    profiles  : pd.DataFrame  [N_days × 24]   columns h00…h23
    daily_X   : pd.DataFrame  [N_days × feats]
    """
    df = hourly.copy()
    df["date"] = df.index.date
    df["hour"] = df.index.hour

    # ── Load profile matrix [N_days × 24] ───────────────────────────────────
    profiles = (
        df.pivot(index="date", columns="hour", values="kw")
          .rename(columns=lambda h: f"h{h:02d}")
    )
    profiles.index = pd.to_datetime(profiles.index)

    # Drop days that are too incomplete
    complete = profiles.notna().sum(axis=1) >= min_hours
    n_dropped = (~complete).sum()
    if n_dropped > 0:
        print(f"  [!] Dropped {n_dropped} days with < {min_hours} valid hours")
    profiles = profiles[complete].interpolate(axis=1, limit=2)

    # ── Daily feature summaries ──────────────────────────────────────────────
    weather_cols = [c for c in df.columns if c not in ("kw", "date", "hour")]

    daily_X = df.groupby("date").agg(
        temp_mean      = ("temp_f",       "mean"),
        temp_max       = ("temp_f",       "max"),
        temp_min       = ("temp_f",       "min"),
        temp_range     = ("temp_f",       lambda x: x.max() - x.min()),
        humidity_mean  = ("humidity_pct", "mean"),
        dew_point_max  = ("dew_point_f",  "max"),   # peak discomfort
        solar_total    = ("solar_wm2",    "sum"),    # daily insolation
        solar_peak     = ("solar_wm2",    "max"),
        wind_mean      = ("wind_mph",     "mean"),
        cloud_mean     = ("cloud_pct",    "mean"),
        precip_total   = ("precip_mm",    "sum"),
        cdh_total      = ("cdh",          "sum"),    # cooling degree hours
        heat_idx_max   = ("heat_index_f", "max"),
        et0_total      = ("et0_mm",       "sum"),
    )
    daily_X.index = pd.to_datetime(daily_X.index)

    # ── Calendar features ────────────────────────────────────────────────────
    daily_X["day_of_week"] = daily_X.index.dayofweek   # 0=Mon … 6=Sun
    daily_X["month"]       = daily_X.index.month
    daily_X["is_weekend"]  = (daily_X["day_of_week"] >= 5).astype(int)
    daily_X["is_friday"]   = (daily_X["day_of_week"] == 4).astype(int)
    daily_X["is_monday"]   = (daily_X["day_of_week"] == 0).astype(int)

    # UH Academic calendar approximate holidays (FY25)
    # Add more dates from https://manoa.hawaii.edu/records/
    uh_holidays = pd.to_datetime([
        "2024-07-04",  # Independence Day
        "2024-08-16",  # Statehood Day
        "2024-09-02",  # Labor Day
        "2024-10-14",  # Indigenous Peoples Day
        "2024-11-11",  # Veterans Day
        "2024-11-28",  # Thanksgiving
        "2024-11-29",  # Day after Thanksgiving
        "2024-12-23",  # Winter recess start (approx)
        "2024-12-24",
        "2024-12-25",  # Christmas
        "2024-12-26",
        "2024-12-27",
        "2024-12-30",
        "2024-12-31",
        "2025-01-01",  # New Year's Day
        "2025-01-02",
        "2025-01-03",
        "2025-01-20",  # MLK Day
        "2025-02-17",  # Presidents Day
        "2025-03-26",  # Prince Kūhiō Day
        "2025-04-18",  # Good Friday
        "2025-05-26",  # Memorial Day
        "2025-06-11",  # Kamehameha Day
    ])
    daily_X["is_holiday"] = daily_X.index.isin(uh_holidays).astype(int)

    # Fiscal week of year (UH FY starts July 1)
    fy_start = pd.Timestamp("2024-07-01")
    daily_X["fy_week"] = np.maximum(0, (daily_X.index - fy_start).days // 7)

    # Cyclical day-of-year encoding
    doy = daily_X.index.dayofyear
    daily_X["doy_sin"] = np.sin(2 * np.pi * doy / 365)
    daily_X["doy_cos"] = np.cos(2 * np.pi * doy / 365)

    # Align to common days
    common = profiles.index.intersection(daily_X.index)
    profiles = profiles.loc[common]
    daily_X  = daily_X.loc[common]

    print(f"── Reshaping to daily profiles ────────────────────────────")
    print(f"  Profile matrix : {profiles.shape}  (days × 24 hours)")
    print(f"  Feature matrix : {daily_X.shape}")
    print(f"  Date range     : {profiles.index.min().date()} "
          f"→ {profiles.index.max().date()}\n")

    return profiles, daily_X


# ══════════════════════════════════════════════════════════════════════════════
# MAIN — Run the full pipeline
# ══════════════════════════════════════════════════════════════════════════════

if __name__ == "__main__":
    print("=" * 60)
    print(" UH Mānoa Load Forecast — Step 1: Data Pipeline")
    print("=" * 60 + "\n")

    # 1. Load meter
    load_hourly = load_meter(METER_CSV)

    # 2. Fetch weather
    weather_raw = fetch_weather(START_DATE, END_DATE)
    weather     = engineer_weather_features(weather_raw)

    # 3. Merge
    hourly = merge(load_hourly, weather)

    # 4. Reshape into daily profiles
    profiles, daily_X = reshape_profiles(hourly)

    # 5. Save for Step 2
    profiles.to_csv("profiles.csv")
    daily_X.to_csv("daily_features.csv")
    hourly.to_csv("hourly_merged.csv")

    print("── Saved files ─────────────────────────────────────────────")
    print("  profiles.csv        → target matrix  [days × 24 hours]")
    print("  daily_features.csv  → feature matrix [days × features]")
    print("  hourly_merged.csv   → full hourly data for reference")
    print()
    print("  → Run step2_features.py next")
