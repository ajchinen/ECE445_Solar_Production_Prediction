"""
step5_forecast.py
=================
UH Mānoa Campus Grid — Load Forecasting Project
------------------------------------------------
WHAT THIS FILE DOES:
  Uses your trained XGBoost models to forecast the load profile for
  any future date (up to 7 days ahead) using Open-Meteo weather forecast.

  This is the "real" use case — predicting load before the day happens.

  Outputs:
    - A printed table of hourly forecast values
    - A PNG plot of the forecasted profile with confidence band

USAGE:
  python step5_forecast.py --date 2025-06-01

  If no date is given, defaults to tomorrow.
"""

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import pickle
import argparse
import openmeteo_requests
import requests_cache
from retry_requests import retry
from datetime import datetime, timedelta
import warnings
warnings.filterwarnings("ignore")

CAMPUS_LAT = 21.2969
CAMPUS_LON = -157.8171
TIMEZONE   = "Pacific/Honolulu"
HOURS      = [f"h{h:02d}" for h in range(24)]
HLABELS    = [f"{h:02d}:00" for h in range(24)]

BG, PANEL, GRID_C = "#0d1117", "#131920", "#1e2633"
WHITE, DIM  = "#e8eaf0", "#8892a4"
TEAL, ORANGE, YELLOW = "#00d4c8", "#ff6b35", "#ffd166"


# ══════════════════════════════════════════════════════════════════════════════
# FETCH FORECAST WEATHER
# ══════════════════════════════════════════════════════════════════════════════

def fetch_forecast_weather(target_date: str) -> pd.DataFrame:
    """
    Pull 7-day hourly weather FORECAST from Open-Meteo for UH Mānoa.
    Returns the 24-hour row for the target date.

    Parameters
    ----------
    target_date : "YYYY-MM-DD" — must be within next 7 days

    Returns
    -------
    pd.DataFrame with same weather columns as the historical data
    """
    print(f"  Fetching forecast weather for {target_date}...")

    cache   = requests_cache.CachedSession(".weather_cache", expire_after=3600)
    session = retry(cache, retries=5, backoff_factor=0.3)
    om      = openmeteo_requests.Client(session=session)

    params = {
        "latitude":  CAMPUS_LAT,
        "longitude": CAMPUS_LON,
        "hourly": [
            "temperature_2m",
            "relative_humidity_2m",
            "dew_point_2m",
            "shortwave_radiation",
            "wind_speed_10m",
            "cloud_cover",
            "precipitation",
            "et0_fao_evapotranspiration",
        ],
        "temperature_unit": "fahrenheit",
        "wind_speed_unit":  "mph",
        "timezone":          TIMEZONE,
        "forecast_days":     7,
    }

    resp   = om.weather_api("https://api.open-meteo.com/v1/forecast",
                             params=params)[0]
    hourly = resp.Hourly()

    col_names = [
        "temp_f", "humidity_pct", "dew_point_f",
        "solar_wm2", "wind_mph", "cloud_pct",
        "precip_mm", "et0_mm",
    ]

    timestamps = pd.date_range(
        start     = pd.to_datetime(hourly.Time(),    unit="s", utc=True),
        end       = pd.to_datetime(hourly.TimeEnd(), unit="s", utc=True),
        freq      = pd.Timedelta(seconds=hourly.Interval()),
        inclusive = "left"
    ).tz_convert(TIMEZONE).tz_localize(None)

    df = pd.DataFrame(
        {n: hourly.Variables(i).ValuesAsNumpy()
         for i, n in enumerate(col_names)},
        index = timestamps
    )

    # Filter to target date only
    day_data = df[df.index.date == pd.to_datetime(target_date).date()]

    if len(day_data) == 0:
        raise ValueError(
            f"No forecast data for {target_date}. "
            "Open-Meteo only forecasts 7 days ahead."
        )

    return day_data


def engineer_weather_features(weather: pd.DataFrame) -> pd.DataFrame:
    """Same transformations as step1_pipeline.py."""
    w = weather.copy()
    T, RH = w["temp_f"], w["humidity_pct"]
    w["cdh"] = (T - 65).clip(lower=0)
    w["heat_index_f"] = (
        -42.379 + 2.04901523*T + 10.14333127*RH - 0.22475541*T*RH
        - 0.00683783*T**2 - 0.05481717*RH**2
        + 0.00122874*T**2*RH + 0.00085282*T*RH**2 - 0.00000199*T**2*RH**2
    )
    w["heat_index_f"] = w[["temp_f","heat_index_f"]].max(axis=1)
    hour = w.index.hour
    month = w.index.month
    w["hour_sin"]  = np.sin(2*np.pi*hour/24)
    w["hour_cos"]  = np.cos(2*np.pi*hour/24)
    w["month_sin"] = np.sin(2*np.pi*month/12)
    w["month_cos"] = np.cos(2*np.pi*month/12)
    return w


# ══════════════════════════════════════════════════════════════════════════════
# BUILD FEATURE ROW FOR FORECAST DAY
# ══════════════════════════════════════════════════════════════════════════════

def build_forecast_features(target_date: str,
                             weather_day: pd.DataFrame,
                             historical_profiles: pd.DataFrame) -> pd.DataFrame:
    """
    Build the feature vector for one future day.

    For a real forecast, lag features come from the most recent
    historical profiles (not from "the future").

    Parameters
    ----------
    target_date         : "YYYY-MM-DD"
    weather_day         : 24-hour weather DataFrame for that day
    historical_profiles : all past profiles (needed for lag features)

    Returns
    -------
    Single-row DataFrame with all features
    """
    target_dt = pd.to_datetime(target_date)

    # ── Daily weather summaries ───────────────────────────────────────────────
    row = {
        "temp_mean"     : weather_day["temp_f"].mean(),
        "temp_max"      : weather_day["temp_f"].max(),
        "temp_min"      : weather_day["temp_f"].min(),
        "temp_range"    : weather_day["temp_f"].max() - weather_day["temp_f"].min(),
        "humidity_mean" : weather_day["humidity_pct"].mean(),
        "dew_point_max" : weather_day["dew_point_f"].max(),
        "solar_total"   : weather_day["solar_wm2"].sum(),
        "solar_peak"    : weather_day["solar_wm2"].max(),
        "wind_mean"     : weather_day["wind_mph"].mean(),
        "cloud_mean"    : weather_day["cloud_pct"].mean(),
        "precip_total"  : weather_day["precip_mm"].sum(),
        "cdh_total"     : weather_day["cdh"].sum(),
        "heat_idx_max"  : weather_day["heat_index_f"].max(),
        "et0_total"     : weather_day["et0_mm"].sum(),
    }

    # ── Calendar features ─────────────────────────────────────────────────────
    dow = target_dt.dayofweek
    row["day_of_week"] = dow
    row["month"]       = target_dt.month
    row["is_weekend"]  = int(dow >= 5)
    row["is_friday"]   = int(dow == 4)
    row["is_monday"]   = int(dow == 0)
    row["is_holiday"]  = 0  # update manually if needed

    fy_start = pd.Timestamp("2024-07-01")
    row["fy_week"] = max(0, (target_dt - fy_start).days // 7)
    doy = target_dt.dayofyear
    row["doy_sin"] = np.sin(2*np.pi*doy/365)
    row["doy_cos"] = np.cos(2*np.pi*doy/365)

    # ── Lag features from historical profiles ─────────────────────────────────
    available = historical_profiles[historical_profiles.index < target_dt]

    if len(available) == 0:
        raise ValueError("No historical profiles available before the target date.")

    # Lag 1: yesterday
    lag1_date = target_dt - pd.Timedelta(days=1)
    lag1 = available.iloc[-1]  # most recent available day
    for h in HOURS:
        row[f"lag1_{h}"] = lag1.get(h, np.nan)
    row["lag1_peak_kw"]   = lag1[HOURS].max()
    row["lag1_mean_kw"]   = lag1[HOURS].mean()
    row["lag1_min_kw"]    = lag1[HOURS].min()
    row["lag1_peak_hour"] = float(np.argmax([lag1.get(h, 0) for h in HOURS]))
    row["lag1_daily_kwh"] = lag1[HOURS].sum()

    # Lag 7: same weekday last week
    lag7_candidates = available[available.index.dayofweek == dow]
    lag7 = lag7_candidates.iloc[-1] if len(lag7_candidates) > 0 else lag1
    for h in HOURS:
        row[f"lag7_{h}"] = lag7.get(h, np.nan)
    row["lag7_peak_kw"]   = lag7[HOURS].max()
    row["lag7_mean_kw"]   = lag7[HOURS].mean()
    row["lag7_daily_kwh"] = lag7[HOURS].sum()

    # Lag 2: two days ago
    lag2 = available.iloc[-2] if len(available) >= 2 else lag1
    for h in HOURS:
        row[f"lag2_{h}"] = lag2.get(h, np.nan)

    # Rolling 7-day mean profile
    recent_7 = available.iloc[-7:] if len(available) >= 7 else available
    roll7_mean = recent_7[HOURS].mean()
    for h in HOURS:
        row[f"roll7_{h}"] = roll7_mean.get(h, np.nan)
    row["roll7_peak_kw"] = roll7_mean.max()
    row["roll7_mean_kw"] = roll7_mean.mean()

    # Rolling weather stats
    row["roll7_temp_mean"] = available["temp_mean"].iloc[-7:].mean() \
                             if "temp_mean" in available.columns else row["temp_mean"]
    row["roll7_cdh_mean"]  = available["cdh_total"].iloc[-7:].mean() \
                             if "cdh_total" in available.columns else row["cdh_total"]

    return pd.DataFrame([row])


# ══════════════════════════════════════════════════════════════════════════════
# GENERATE AND PLOT FORECAST
# ══════════════════════════════════════════════════════════════════════════════

def forecast(target_date: str, xgb_models: dict,
             historical_profiles: pd.DataFrame) -> pd.Series:
    """Run the forecast for one future day."""

    # 1. Fetch weather forecast
    weather_raw = fetch_forecast_weather(target_date)
    weather_day = engineer_weather_features(weather_raw)

    # 2. Build feature row
    X = build_forecast_features(target_date, weather_day, historical_profiles)

    # 3. Align to training feature columns
    # Load training column list from saved file
    X_train = pd.read_csv("X_train.csv", index_col=0, parse_dates=True, nrows=1)
    for col in X_train.columns:
        if col not in X.columns:
            X[col] = 0.0   # fill unseen columns with 0
    X = X[X_train.columns]

    # 4. Predict with each hour's XGBoost model
    preds = {h: float(xgb_models[h].predict(X.values)[0]) for h in HOURS}
    forecast_series = pd.Series(preds)

    print(f"\n── Forecast for {target_date} ──────────────────────────────")
    print(f"  {'Hour':<8}  {'kW':>8}")
    print(f"  {'─'*18}")
    for h, kw in zip(HLABELS, forecast_series.values):
        bar = "█" * int(kw / 400)
        print(f"  {h:<8}  {kw:>8.0f}  {bar}")

    print(f"\n  Predicted peak : {forecast_series.max():.0f} kW "
          f"@ {HLABELS[forecast_series.argmax()]}")
    print(f"  Predicted daily energy : {forecast_series.sum():.0f} kWh (approx)")

    # 5. Plot
    _plot_forecast(target_date, forecast_series, weather_day)

    return forecast_series


def _plot_forecast(date: str, forecast: pd.Series, weather: pd.DataFrame):
    fig, axes = plt.subplots(2, 1, figsize=(13, 8),
                              facecolor=BG, gridspec_kw={"height_ratios": [3, 1]})

    # ── Top: forecast profile ─────────────────────────────────────────────────
    ax = axes[0]
    ax.set_facecolor(PANEL)
    for sp in ax.spines.values(): sp.set_edgecolor(GRID_C)
    ax.tick_params(colors=DIM, labelsize=8.5)
    ax.grid(True, color=GRID_C, linewidth=0.6, linestyle="--")

    y = forecast.values
    # Approx ±5% uncertainty band from cross-validation
    sigma = y * 0.05

    ax.fill_between(range(24), y - 2*sigma, y + 2*sigma,
                    color=TEAL, alpha=0.07, label="±2σ (95% CI)")
    ax.fill_between(range(24), y - sigma,   y + sigma,
                    color=TEAL, alpha=0.15, label="±1σ (68% CI)")
    ax.plot(range(24), y, color=TEAL, linewidth=2.5, label="Forecast (XGBoost)")
    ax.scatter(range(24), y, color=TEAL, s=30, zorder=5, alpha=0.8)

    # Peak annotation
    peak_h = int(np.argmax(y))
    ax.annotate(f"  Peak: {y[peak_h]:.0f} kW",
                xy=(peak_h, y[peak_h]),
                xytext=(peak_h + 2, y[peak_h] + 200),
                color=YELLOW, fontsize=9, fontweight="bold",
                arrowprops=dict(arrowstyle="->", color=YELLOW, lw=1.3),
                bbox=dict(facecolor=BG, edgecolor=YELLOW, linewidth=1,
                          boxstyle="round,pad=0.3"))

    ax.set_title(f"Load Profile Forecast — {pd.to_datetime(date).strftime('%A, %B %d, %Y')}  "
                 f"·  UH Mānoa Substation  ·  XGBoost",
                 color=WHITE, fontsize=11, fontweight="bold", pad=10)
    ax.set_ylabel("Load (kW)", color=DIM, fontsize=9)
    ax.set_xlim(-0.5, 23.5)
    ax.set_xticks(range(24))
    ax.set_xticklabels(HLABELS, rotation=45, ha="right", fontsize=7.5)
    ax.legend(facecolor=PANEL, edgecolor=GRID_C, labelcolor=WHITE, fontsize=8.5)

    # ── Bottom: weather ───────────────────────────────────────────────────────
    ax2 = axes[1]
    ax2.set_facecolor(PANEL)
    for sp in ax2.spines.values(): sp.set_edgecolor(GRID_C)
    ax2.tick_params(colors=DIM, labelsize=8)
    ax2.grid(True, color=GRID_C, linewidth=0.5, linestyle="--")

    ax3 = ax2.twinx()
    ax3.set_facecolor(PANEL)
    for sp in ax3.spines.values(): sp.set_edgecolor(GRID_C)

    ax2.plot(range(24), weather["temp_f"].values, color=ORANGE,
             linewidth=1.8, label="Temp (°F)")
    ax2.fill_between(range(24), weather["temp_f"].values.min(),
                     weather["temp_f"].values, color=ORANGE, alpha=0.07)
    ax3.fill_between(range(24), 0, weather["solar_wm2"].values,
                     color=YELLOW, alpha=0.2, label="Solar (W/m²)")
    ax3.plot(range(24), weather["solar_wm2"].values,
             color=YELLOW, linewidth=1.5, alpha=0.7)

    ax2.set_ylabel("Temp (°F)", color=ORANGE, fontsize=8.5)
    ax3.set_ylabel("Solar W/m²", color=YELLOW, fontsize=8.5)
    ax2.tick_params(axis='y', colors=ORANGE)
    ax3.tick_params(axis='y', colors=YELLOW)
    ax2.set_xlim(-0.5, 23.5)
    ax2.set_xticks(range(0, 24, 2))
    ax2.set_xticklabels([HLABELS[h] for h in range(0, 24, 2)],
                        rotation=30, ha="right", fontsize=7.5)

    save = f"forecast_{date}.png"
    plt.tight_layout()
    plt.savefig(save, dpi=150, bbox_inches="tight", facecolor=BG)
    plt.close()
    print(f"\n  Plot saved: {save}")


# ══════════════════════════════════════════════════════════════════════════════
# MAIN
# ══════════════════════════════════════════════════════════════════════════════

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Forecast campus load for a future date.")
    parser.add_argument("--date", type=str,
                        default=(datetime.today() + timedelta(days=1)).strftime("%Y-%m-%d"),
                        help="Target date YYYY-MM-DD (default: tomorrow)")
    args = parser.parse_args()

    print("=" * 60)
    print(f" UH Mānoa Load Forecast — Step 5: Generate Forecast")
    print(f" Target date: {args.date}")
    print("=" * 60 + "\n")

    # Load trained models
    with open("xgb_models.pkl", "rb") as f:
        xgb_models = pickle.load(f)

    # Load historical profiles (needed for lag features)
    profiles = pd.read_csv("profiles.csv", index_col=0, parse_dates=True)

    # Run forecast
    result = forecast(args.date, xgb_models, profiles)
