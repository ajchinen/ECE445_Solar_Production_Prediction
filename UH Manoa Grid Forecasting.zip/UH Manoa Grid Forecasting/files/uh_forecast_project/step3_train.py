"""
step3_train.py
==============
UH Mānoa Campus Grid — Load Forecasting Project
------------------------------------------------
WHAT THIS FILE DOES:
  Trains four models in increasing complexity, evaluates each one,
  and saves the best model for use in step4_forecast.py.

  Models trained:
    1. Persistence  — "tomorrow = yesterday"  (floor baseline)
    2. Mean Profile — average curve per day-of-week  (smart baseline)
    3. Ridge Linear — linear regression, all 24 hours at once
    4. XGBoost      — gradient boosted trees, one model per hour  ← MAIN MODEL

  All models are evaluated on the held-out test set (last 60 days)
  using the same metrics so comparison is fair.
"""

import pandas as pd
import numpy as np
import xgboost as xgb
from sklearn.linear_model import Ridge
from sklearn.multioutput import MultiOutputRegressor
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import Pipeline
import pickle
import warnings
warnings.filterwarnings("ignore")

HOURS = [f"h{h:02d}" for h in range(24)]


# ══════════════════════════════════════════════════════════════════════════════
# METRICS
# ══════════════════════════════════════════════════════════════════════════════

def evaluate(name: str, Y_true: pd.DataFrame,
             Y_pred: pd.DataFrame) -> dict:
    """
    Compute a full suite of profile-level metrics and print a summary.

    Metrics explained
    -----------------
    MAE  (Mean Absolute Error)
        Average kW error across all hours and all days.
        Interpretable: "on average I'm off by X kW."

    RMSE (Root Mean Squared Error)
        Like MAE but squares errors first, so large misses are penalized more.
        RMSE > MAE means your model has occasional bad days.

    MAPE (Mean Absolute Percentage Error)
        Error as a percentage of the actual value.
        Useful for comparing across different scales.
        MAPE = 3% means you're within 3% on average.

    Peak Error
        How close your predicted daily peak is to the actual peak (kW).
        Critical for grid planning — utilities need to know the maximum load.

    Peak Timing Error
        How many hours off is your predicted peak time from the actual peak?
        Being accurate in magnitude but off by 2 hours is still a problem
        for demand response scheduling.

    Daily Energy Error
        Total kWh error per day (sum of 24 hourly kW values).
        Billing and renewable integration depend on this.

    Profile Correlation
        Pearson r between predicted and actual 24-hour curves, averaged
        over all test days. r=1.0 means perfect shape, r<0.9 means
        the curve shape is wrong.
    """
    true = Y_true.values
    pred = Y_pred.values
    err  = pred - true

    mae   = float(np.abs(err).mean())
    rmse  = float(np.sqrt((err**2).mean()))
    mape  = float(np.abs(err / (true + 1e-6)).mean() * 100)

    # Peak metrics (per day)
    peak_true     = true.max(axis=1)
    peak_pred     = pred.max(axis=1)
    peak_err      = float(np.abs(peak_pred - peak_true).mean())
    peak_time_err = float(
        np.abs(np.argmax(pred, axis=1) - np.argmax(true, axis=1)).mean()
    )

    # Daily energy error
    energy_true   = true.sum(axis=1)
    energy_pred   = pred.sum(axis=1)
    energy_err_pct= float(
        np.abs((energy_pred - energy_true) / energy_true).mean() * 100
    )

    # Profile shape correlation (average Pearson r per day)
    corrs = [np.corrcoef(true[i], pred[i])[0,1] for i in range(len(true))]
    profile_r = float(np.mean(corrs))

    metrics = dict(
        mae=mae, rmse=rmse, mape=mape,
        peak_err=peak_err, peak_time_err=peak_time_err,
        energy_err_pct=energy_err_pct, profile_r=profile_r
    )

    w = 12
    print(f"\n  {'─'*42}")
    print(f"  {name}")
    print(f"  {'─'*42}")
    print(f"  {'MAE':<{w}}  {mae:>8.0f} kW")
    print(f"  {'RMSE':<{w}}  {rmse:>8.0f} kW")
    print(f"  {'MAPE':<{w}}  {mape:>8.2f} %")
    print(f"  {'Peak error':<{w}}  {peak_err:>8.0f} kW")
    print(f"  {'Peak timing':<{w}}  {peak_time_err:>8.1f} hrs")
    print(f"  {'Energy error':<{w}}  {energy_err_pct:>8.2f} %")
    print(f"  {'Profile r':<{w}}  {profile_r:>8.4f}")

    return metrics


# ══════════════════════════════════════════════════════════════════════════════
# MODEL 1 — Persistence Baseline
# ══════════════════════════════════════════════════════════════════════════════

def predict_persistence(X_test: pd.DataFrame) -> pd.DataFrame:
    """
    Predict tomorrow = yesterday.

    This uses the lag1 features already in X_test, which contain
    yesterday's full 24-hour profile. No training needed.

    This is your FLOOR — any real model must beat this.
    If your XGBoost doesn't beat persistence, something is wrong.
    """
    lag1_cols = [c for c in X_test.columns if c.startswith("lag1_h")]
    preds = X_test[lag1_cols].copy()
    preds.columns = HOURS
    return preds


# ══════════════════════════════════════════════════════════════════════════════
# MODEL 2 — Mean Profile by Day-of-Week
# ══════════════════════════════════════════════════════════════════════════════

def fit_mean_profile(X_train: pd.DataFrame,
                     Y_train: pd.DataFrame) -> dict:
    """
    Compute the average load profile for each day of the week.

    Mon average, Tue average, …, Sun average.
    On test days, look up which day of the week it is and return
    that day's average profile.

    This captures the biggest signal: weekday vs. weekend difference.
    Surprisingly hard to beat with 6 months of data.
    """
    model = {}
    for dow in range(7):
        mask = X_train.index.dayofweek == dow
        if mask.sum() > 0:
            model[dow] = Y_train[mask].mean().values
    model["overall"] = Y_train.mean().values
    return model


def predict_mean_profile(model: dict,
                          X_test: pd.DataFrame) -> pd.DataFrame:
    preds = np.array([
        model.get(dow, model["overall"])
        for dow in X_test.index.dayofweek
    ])
    return pd.DataFrame(preds, index=X_test.index, columns=HOURS)


# ══════════════════════════════════════════════════════════════════════════════
# MODEL 3 — Multi-Output Ridge Regression
# ══════════════════════════════════════════════════════════════════════════════

def fit_ridge(X_train: pd.DataFrame,
              Y_train: pd.DataFrame,
              alpha: float = 10.0) -> Pipeline:
    """
    Predict all 24 hours simultaneously with regularized linear regression.

    WHY RIDGE (not plain linear regression)?
    -----------------------------------------
    With ~150+ features, plain linear regression will overfit — it finds
    weights that perfectly explain training data but fail on new days.

    Ridge adds a penalty: Loss = MSE + α × Σ(weights²)
    This shrinks large weights toward zero, producing a simpler model
    that generalizes better.

    α (alpha) controls regularization strength:
      • α too small → overfits (like plain linear regression)
      • α too large → underfits (all weights → 0, model predicts mean)
      • α = 10 is a reasonable starting point; tune if needed

    StandardScaler is applied first because Ridge is sensitive to
    feature scale. Temperature in °F (60–90) and solar in W/m² (0–800)
    are very different scales — scaling puts them on equal footing.
    """
    model = Pipeline([
        ("scaler", StandardScaler()),
        ("ridge",  MultiOutputRegressor(Ridge(alpha=alpha), n_jobs=-1))
    ])
    model.fit(X_train.values, Y_train.values)
    return model


def predict_ridge(model: Pipeline,
                  X_test: pd.DataFrame) -> pd.DataFrame:
    preds = model.predict(X_test.values)
    return pd.DataFrame(preds, index=X_test.index, columns=HOURS)


# ══════════════════════════════════════════════════════════════════════════════
# MODEL 4 — XGBoost (One Per Hour)
# ══════════════════════════════════════════════════════════════════════════════

def fit_xgboost(X_train: pd.DataFrame,
                Y_train: pd.DataFrame,
                X_val:   pd.DataFrame = None,
                Y_val:   pd.DataFrame = None) -> dict:
    """
    Train one XGBoost model per hour of the day (24 models total).

    WHY ONE MODEL PER HOUR?
    -----------------------
    Load at midnight (h00) and load at 2pm (h14) are driven by completely
    different physical processes:
      h00: base load — servers, refrigeration, minimal occupancy
      h14: peak AC load — depends heavily on that day's solar + temperature

    Training separate models lets each hour learn different feature weights.
    For example, h14 will heavily weight solar_wm2 and temp_max, while
    h03 barely cares about those.

    HOW XGBOOST WORKS
    -----------------
    XGBoost builds an ensemble (collection) of decision trees where each
    tree corrects the mistakes of all previous trees:

      Iteration 1: Tree 1 predicts from features. Big errors remain.
      Iteration 2: Tree 2 fits the RESIDUALS (errors from Tree 1).
      Iteration 3: Tree 3 fits the residuals of (Tree 1 + Tree 2).
      ...
      Final: Ŷ = T₁(x) + T₂(x) + ... + T_n(x)

    Key hyperparameters
    -------------------
    n_estimators (300)
        Number of trees. More = better fit but slower and overfits if too high.

    max_depth (4)
        How deep each tree can go. Deeper = more complex, more overfit risk.
        Depth 4 means up to 2^4=16 leaf nodes per tree.

    learning_rate (0.05)
        How much each tree's contribution is scaled down.
        Lower rate + more trees usually beats higher rate + fewer trees.

    subsample (0.8)
        Each tree only sees 80% of training rows (randomly sampled).
        Adds randomness that prevents overfitting.

    colsample_bytree (0.7)
        Each tree only sees 70% of features.
        Same idea — adds randomness, reduces overfitting.

    min_child_weight (5)
        A leaf must contain at least 5 samples.
        Prevents trees from memorizing individual training days.

    Parameters
    ----------
    X_val, Y_val : optional validation set for early stopping.
                   If provided, training stops when validation error
                   stops improving (prevents overfitting automatically).
    """
    models = {}
    X = X_train.values
    use_early_stopping = X_val is not None and Y_val is not None

    print(f"  Training 24 XGBoost models {'(with early stopping)' if use_early_stopping else ''}...")

    for i, hour in enumerate(HOURS):
        y = Y_train[hour].values

        params = dict(
            n_estimators     = 500 if use_early_stopping else 300,
            max_depth        = 4,
            learning_rate    = 0.05,
            subsample        = 0.8,
            colsample_bytree = 0.7,
            min_child_weight = 5,
            reg_alpha        = 0.1,   # L1 regularization
            reg_lambda       = 1.0,   # L2 regularization
            n_jobs           = -1,
            random_state     = 42,
            tree_method      = "hist",
            eval_metric      = "mae",
            early_stopping_rounds = 30 if use_early_stopping else None,
        )

        model = xgb.XGBRegressor(**params)

        fit_kwargs = {}
        if use_early_stopping:
            fit_kwargs["eval_set"] = [(X_val.values, Y_val[hour].values)]
            fit_kwargs["verbose"]  = False

        model.fit(X, y, **fit_kwargs)
        models[hour] = model

        if (i + 1) % 8 == 0 or i == 23:
            print(f"    ... finished hour {i+1:02d}/24")

    return models


def predict_xgboost(models: dict,
                    X_test: pd.DataFrame) -> pd.DataFrame:
    X     = X_test.values
    preds = np.column_stack([models[h].predict(X) for h in HOURS])
    return pd.DataFrame(preds, index=X_test.index, columns=HOURS)


def get_feature_importance(models: dict,
                            feature_names: list,
                            top_n: int = 15) -> pd.DataFrame:
    """
    Average feature importance across all 24 hour-models.
    Shows which features the model relies on most overall.
    """
    importances = pd.DataFrame({
        hour: models[hour].feature_importances_
        for hour in HOURS
    }, index=feature_names)

    avg = importances.mean(axis=1).sort_values(ascending=False)
    return avg.head(top_n).to_frame("avg_importance")


# ══════════════════════════════════════════════════════════════════════════════
# MAIN
# ══════════════════════════════════════════════════════════════════════════════

if __name__ == "__main__":
    print("=" * 60)
    print(" UH Mānoa Load Forecast — Step 3: Model Training")
    print("=" * 60 + "\n")

    # Load data from Step 2
    X_train = pd.read_csv("X_train.csv", index_col=0, parse_dates=True)
    X_test  = pd.read_csv("X_test.csv",  index_col=0, parse_dates=True)
    Y_train = pd.read_csv("Y_train.csv", index_col=0, parse_dates=True)
    Y_test  = pd.read_csv("Y_test.csv",  index_col=0, parse_dates=True)

    print(f"  Training days : {len(X_train)}")
    print(f"  Test days     : {len(X_test)}")
    print(f"  Features      : {X_train.shape[1]}\n")

    results = {}

    # ── Model 1: Persistence ─────────────────────────────────────────────────
    print("\n── Model 1: Persistence Baseline ───────────────────────────")
    pred_persist = predict_persistence(X_test)
    results["Persistence"] = evaluate("Persistence", Y_test, pred_persist)

    # ── Model 2: Mean Profile ────────────────────────────────────────────────
    print("\n── Model 2: Mean Profile by Day-of-Week ────────────────────")
    mean_model = fit_mean_profile(X_train, Y_train)
    pred_mean  = predict_mean_profile(mean_model, X_test)
    results["Mean Profile"] = evaluate("Mean Profile", Y_test, pred_mean)

    # ── Model 3: Ridge Regression ────────────────────────────────────────────
    print("\n── Model 3: Ridge Regression ───────────────────────────────")
    ridge_model = fit_ridge(X_train, Y_train, alpha=10.0)
    pred_ridge  = predict_ridge(ridge_model, X_test)
    results["Ridge"] = evaluate("Ridge Regression", Y_test, pred_ridge)

    # ── Model 4: XGBoost ─────────────────────────────────────────────────────
    print("\n── Model 4: XGBoost (24 hour-models) ───────────────────────")
    # Use last 30 days of training data as validation for early stopping
    val_days    = 30
    X_tr        = X_train.iloc[:-val_days]
    X_val       = X_train.iloc[-val_days:]
    Y_tr        = Y_train.iloc[:-val_days]
    Y_val       = Y_train.iloc[-val_days:]
    xgb_models  = fit_xgboost(X_tr, Y_tr, X_val, Y_val)
    pred_xgb    = predict_xgboost(xgb_models, X_test)
    results["XGBoost"] = evaluate("XGBoost", Y_test, pred_xgb)

    # ── Results comparison ───────────────────────────────────────────────────
    print("\n\n── Summary: All Models on Test Set ─────────────────────────")
    summary = pd.DataFrame(results).T
    print(summary.to_string(float_format=lambda x: f"{x:.2f}"))

    # ── Feature importance ───────────────────────────────────────────────────
    print("\n── Top 15 Most Important Features (XGBoost) ───────────────")
    fi = get_feature_importance(xgb_models, list(X_train.columns))
    print(fi.to_string())

    # ── Save models and predictions ──────────────────────────────────────────
    with open("xgb_models.pkl", "wb") as f:
        pickle.dump(xgb_models, f)
    with open("ridge_model.pkl", "wb") as f:
        pickle.dump(ridge_model, f)

    pred_xgb.to_csv("predictions_xgb.csv")
    pred_ridge.to_csv("predictions_ridge.csv")
    pred_persist.to_csv("predictions_persistence.csv")
    pred_mean.to_csv("predictions_mean.csv")
    summary.to_csv("model_comparison.csv")

    print("\n── Saved ───────────────────────────────────────────────────")
    print("  xgb_models.pkl          → trained XGBoost models")
    print("  predictions_xgb.csv     → XGBoost test predictions")
    print("  model_comparison.csv    → metrics table")
    print()
    print("  → Run step4_visualize.py next")
