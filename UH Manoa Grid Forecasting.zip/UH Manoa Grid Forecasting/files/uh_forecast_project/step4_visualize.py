"""
step4_visualize.py
==================
UH Mānoa Campus Grid — Load Forecasting Project
------------------------------------------------
WHAT THIS FILE DOES:
  Generates all plots for your project report and presentation.
  Reads the outputs from steps 1–3 and produces:

  Plot 1 — EDA: Full year load heatmap
  Plot 2 — EDA: Average profiles by day-of-week
  Plot 3 — EDA: Load vs. temperature scatter
  Plot 4 — EDA: ACF (autocorrelation) of hourly load
  Plot 5 — Model: Predicted vs. actual for individual test days
  Plot 6 — Model: Hourly MAE comparison across models
  Plot 7 — Model: Error heatmap (hour × day-of-week)
  Plot 8 — Model: Feature importance (XGBoost)
"""

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec
import matplotlib.colors as mcolors
from matplotlib.lines import Line2D
import warnings
warnings.filterwarnings("ignore")

# ── Style ──────────────────────────────────────────────────────────────────────
BG       = "#0d1117"
PANEL    = "#131920"
GRID_C   = "#1e2633"
WHITE    = "#e8eaf0"
DIM      = "#8892a4"
TEAL     = "#00d4c8"
ORANGE   = "#ff6b35"
YELLOW   = "#ffd166"
GREEN    = "#00c97a"
PURPLE   = "#b48ead"
HOURS    = [f"h{h:02d}" for h in range(24)]
HLABELS  = [f"{h:02d}:00" for h in range(24)]

plt.rcParams.update({
    "figure.facecolor":  BG,
    "axes.facecolor":    PANEL,
    "axes.edgecolor":    GRID_C,
    "axes.labelcolor":   DIM,
    "text.color":        WHITE,
    "xtick.color":       DIM,
    "ytick.color":       DIM,
    "grid.color":        GRID_C,
    "grid.linewidth":    0.6,
    "grid.linestyle":    "--",
    "legend.facecolor":  PANEL,
    "legend.edgecolor":  GRID_C,
    "font.family":       "monospace",
})


def sax(ax, title="", xlabel="", ylabel=""):
    ax.set_facecolor(PANEL)
    for sp in ax.spines.values():
        sp.set_edgecolor(GRID_C)
    ax.tick_params(colors=DIM, labelsize=8.5)
    if title:   ax.set_title(title, color=WHITE, fontsize=10, fontweight="bold",
                              loc="left", pad=7)
    if xlabel:  ax.set_xlabel(xlabel, fontsize=9)
    if ylabel:  ax.set_ylabel(ylabel, fontsize=9)
    ax.grid(True)


# ══════════════════════════════════════════════════════════════════════════════
# PLOT 1 — EDA: Full-Year Load Heatmap
# ══════════════════════════════════════════════════════════════════════════════

def plot_heatmap(profiles: pd.DataFrame, save="plot1_heatmap.png"):
    """
    Heatmap of load [days × hours]. Color = kW intensity.
    This single plot reveals: daily rhythm, weekly pattern,
    semester vs. break periods, holidays.
    """
    fig, ax = plt.subplots(figsize=(16, 7), facecolor=BG)
    sax(ax, "Full-Year Campus Load Heatmap  [kW]",
        xlabel="Hour of Day", ylabel="Day (FY25: Jul 2024 → Jun 2025)")

    data = profiles[HOURS].values

    im = ax.imshow(data, aspect="auto", cmap="YlOrRd",
                   interpolation="nearest",
                   extent=[-0.5, 23.5, len(data)+0.5, 0.5])

    cbar = plt.colorbar(im, ax=ax, pad=0.01, shrink=0.85)
    cbar.ax.tick_params(colors=DIM, labelsize=8)
    cbar.set_label("kW", color=DIM, fontsize=9)

    ax.set_xticks(range(0, 24, 2))
    ax.set_xticklabels([HLABELS[h] for h in range(0, 24, 2)], rotation=30, ha="right")

    # Y-axis: label every 30 days
    tick_positions = list(range(0, len(profiles), 30))
    tick_labels    = [profiles.index[i].strftime("%b %d") for i in tick_positions]
    ax.set_yticks([p + 1 for p in tick_positions])
    ax.set_yticklabels(tick_labels, fontsize=8)

    fig.text(0.12, 0.97,
             "UH Mānoa Substation  ·  15-min data resampled to hourly",
             color=DIM, fontsize=8.5)

    plt.tight_layout()
    plt.savefig(save, dpi=150, bbox_inches="tight", facecolor=BG)
    plt.close()
    print(f"  Saved: {save}")


# ══════════════════════════════════════════════════════════════════════════════
# PLOT 2 — EDA: Average Profile by Day-of-Week
# ══════════════════════════════════════════════════════════════════════════════

def plot_dow_profiles(profiles: pd.DataFrame, save="plot2_dow_profiles.png"):
    """Show the 7 average daily curves. Reveals weekday vs. weekend patterns."""
    fig, axes = plt.subplots(1, 2, figsize=(14, 5), facecolor=BG)

    dow_names = ["Monday","Tuesday","Wednesday","Thursday","Friday","Saturday","Sunday"]
    colors_wd = [TEAL, TEAL, TEAL, TEAL, YELLOW]
    colors_we = [ORANGE, PURPLE]

    ax = axes[0]
    sax(ax, "Average Load Profile — Weekdays",
        xlabel="Hour", ylabel="Load (kW)")
    for i in range(5):
        mask    = profiles.index.dayofweek == i
        profile = profiles[mask][HOURS].mean()
        ax.plot(range(24), profile.values, color=colors_wd[i],
                linewidth=2.0, label=dow_names[i], alpha=0.85)
        ax.fill_between(range(24),
                        profiles[mask][HOURS].quantile(0.1),
                        profiles[mask][HOURS].quantile(0.9),
                        color=colors_wd[i], alpha=0.05)
    ax.set_xticks(range(0, 24, 3))
    ax.set_xticklabels([HLABELS[h] for h in range(0, 24, 3)], rotation=30, ha="right")
    ax.legend(labelcolor=WHITE, fontsize=8.5)

    ax2 = axes[1]
    sax(ax2, "Average Load Profile — Weekend",
        xlabel="Hour", ylabel="Load (kW)")
    for j, i in enumerate([5, 6]):
        mask    = profiles.index.dayofweek == i
        profile = profiles[mask][HOURS].mean()
        ax2.plot(range(24), profile.values, color=colors_we[j],
                 linewidth=2.2, label=dow_names[i])
        ax2.fill_between(range(24),
                         profiles[mask][HOURS].quantile(0.1),
                         profiles[mask][HOURS].quantile(0.9),
                         color=colors_we[j], alpha=0.08)
    # Overlay mean weekday for comparison
    wd_mask = profiles.index.dayofweek < 5
    ax2.plot(range(24), profiles[wd_mask][HOURS].mean().values,
             color=DIM, linewidth=1.5, linestyle=":", label="Weekday avg")
    ax2.set_xticks(range(0, 24, 3))
    ax2.set_xticklabels([HLABELS[h] for h in range(0, 24, 3)], rotation=30, ha="right")
    ax2.legend(labelcolor=WHITE, fontsize=8.5)

    plt.tight_layout()
    plt.savefig(save, dpi=150, bbox_inches="tight", facecolor=BG)
    plt.close()
    print(f"  Saved: {save}")


# ══════════════════════════════════════════════════════════════════════════════
# PLOT 3 — EDA: Load vs. Temperature
# ══════════════════════════════════════════════════════════════════════════════

def plot_load_vs_temp(hourly: pd.DataFrame, save="plot3_load_vs_temp.png"):
    """Scatter of hourly kW vs temperature, colored by hour. Shows cooling curve."""
    fig, axes = plt.subplots(1, 2, figsize=(14, 5), facecolor=BG)

    ax = axes[0]
    sax(ax, "Load vs. Temperature (by hour)",
        xlabel="Temperature (°F)", ylabel="Load (kW)")
    sc = ax.scatter(hourly["temp_f"], hourly["kw"],
                    c=hourly.index.hour, cmap="plasma",
                    s=6, alpha=0.4, edgecolors="none")
    cbar = plt.colorbar(sc, ax=ax, pad=0.02)
    cbar.set_label("Hour of Day", color=DIM, fontsize=8.5)
    cbar.ax.tick_params(colors=DIM, labelsize=8)

    # Trend line
    z = np.polyfit(hourly["temp_f"].dropna(), hourly["kw"].dropna(), 2)
    t_range = np.linspace(hourly["temp_f"].min(), hourly["temp_f"].max(), 100)
    ax.plot(t_range, np.polyval(z, t_range),
            color=TEAL, linewidth=2.0, label="Quadratic fit")
    ax.legend(labelcolor=WHITE, fontsize=8.5)

    # Box plots by temperature bin
    ax2 = axes[1]
    sax(ax2, "Load Distribution by Temp Band",
        xlabel="Temperature Band (°F)", ylabel="Load (kW)")
    bins   = pd.cut(hourly["temp_f"], bins=range(65, 95, 5))
    groups = [hourly.loc[bins == b, "kw"].dropna().values
              for b in bins.cat.categories]
    labels = [str(b) for b in bins.cat.categories]
    bp = ax2.boxplot(groups, labels=labels, patch_artist=True,
                     medianprops=dict(color=ORANGE, linewidth=2),
                     whiskerprops=dict(color=DIM),
                     capprops=dict(color=DIM),
                     flierprops=dict(marker=".", color=DIM, markersize=2, alpha=0.3))
    for patch in bp["boxes"]:
        patch.set(facecolor=TEAL, alpha=0.3, edgecolor=TEAL)
    ax2.set_xticklabels(labels, rotation=30, ha="right")

    plt.tight_layout()
    plt.savefig(save, dpi=150, bbox_inches="tight", facecolor=BG)
    plt.close()
    print(f"  Saved: {save}")


# ══════════════════════════════════════════════════════════════════════════════
# PLOT 4 — EDA: Autocorrelation (ACF)
# ══════════════════════════════════════════════════════════════════════════════

def plot_acf(hourly: pd.DataFrame, save="plot4_acf.png"):
    """
    Autocorrelation at lags 1–200 hours.
    Spikes at 24h (yesterday) and 168h (last week) confirm lag features.
    """
    load = hourly["kw"].dropna().values
    n    = len(load)
    lags = range(1, 200)
    mean = load.mean()
    var  = ((load - mean)**2).mean()

    acf_vals = [
        ((load[:n-k] - mean) * (load[k:] - mean)).mean() / var
        for k in lags
    ]

    fig, ax = plt.subplots(figsize=(14, 4), facecolor=BG)
    sax(ax, "Autocorrelation of Hourly Load  (ACF)",
        xlabel="Lag (hours)", ylabel="Correlation")

    ax.bar(list(lags), acf_vals, color=TEAL, alpha=0.6, width=1.0)
    ax.axhline(0, color=WHITE, linewidth=0.8, alpha=0.4)

    # Confidence interval (95%)
    ci = 1.96 / np.sqrt(n)
    ax.axhline(ci,  color=YELLOW, linewidth=1.0, linestyle="--", alpha=0.6)
    ax.axhline(-ci, color=YELLOW, linewidth=1.0, linestyle="--", alpha=0.6)

    # Annotate key lags
    for lag, label in [(24, "24h\n(yesterday)"), (48, "48h"), (168, "168h\n(last week)")]:
        if lag < 200:
            val = acf_vals[lag - 1]
            ax.annotate(label, xy=(lag, val),
                        xytext=(lag + 4, val + 0.05),
                        color=ORANGE, fontsize=8.5, fontweight="bold",
                        arrowprops=dict(arrowstyle="->", color=ORANGE, lw=1.2))

    ax.set_xlim(0, 200)
    plt.tight_layout()
    plt.savefig(save, dpi=150, bbox_inches="tight", facecolor=BG)
    plt.close()
    print(f"  Saved: {save}")


# ══════════════════════════════════════════════════════════════════════════════
# PLOT 5 — Model: Predicted vs Actual (Individual Days)
# ══════════════════════════════════════════════════════════════════════════════

def plot_forecast_days(Y_test: pd.DataFrame,
                       pred_xgb: pd.DataFrame,
                       pred_persist: pd.DataFrame,
                       n_days: int = 6,
                       save: str = "plot5_forecast_days.png"):
    """Show predicted vs actual for 6 representative test days."""
    fig, axes = plt.subplots(2, 3, figsize=(16, 8), facecolor=BG)
    axes = axes.flatten()

    # Pick 6 evenly spaced test days
    indices = np.linspace(0, len(Y_test) - 1, n_days, dtype=int)

    for i, idx in enumerate(indices):
        ax    = axes[i]
        date  = Y_test.index[idx]
        actual = Y_test.iloc[idx].values
        xgb    = pred_xgb.iloc[idx].values
        pers   = pred_persist.iloc[idx].values
        dow    = date.strftime("%A")

        mae_xgb  = np.abs(xgb - actual).mean()
        mae_pers = np.abs(pers - actual).mean()

        sax(ax, f"{date.strftime('%b %d, %Y')} ({dow})",
            xlabel="Hour", ylabel="Load (kW)")

        ax.fill_between(range(24), xgb - 300, xgb + 300,
                        color=TEAL, alpha=0.12)
        ax.plot(range(24), pers,   color=DIM,    linewidth=1.5,
                linestyle=":", label=f"Persistence  MAE={mae_pers:.0f}")
        ax.plot(range(24), actual, color=ORANGE,  linewidth=2.2,
                label="Actual")
        ax.plot(range(24), xgb,    color=TEAL,    linewidth=2.2,
                linestyle="--", label=f"XGBoost  MAE={mae_xgb:.0f}")

        ax.set_xticks(range(0, 24, 4))
        ax.set_xticklabels([HLABELS[h] for h in range(0, 24, 4)],
                           rotation=30, ha="right")
        ax.legend(labelcolor=WHITE, fontsize=7.5, loc="upper left")

    plt.suptitle("Predicted vs. Actual Load Profiles — Test Days",
                 color=WHITE, fontsize=12, fontweight="bold", y=1.01)
    plt.tight_layout()
    plt.savefig(save, dpi=150, bbox_inches="tight", facecolor=BG)
    plt.close()
    print(f"  Saved: {save}")


# ══════════════════════════════════════════════════════════════════════════════
# PLOT 6 — Model: Hourly MAE Comparison
# ══════════════════════════════════════════════════════════════════════════════

def plot_hourly_mae(Y_test: pd.DataFrame,
                   pred_dict: dict,
                   save: str = "plot6_hourly_mae.png"):
    """Show MAE at each hour for each model. Reveals when models struggle."""
    fig, ax = plt.subplots(figsize=(14, 5), facecolor=BG)
    sax(ax, "Hourly MAE by Model — Test Set",
        xlabel="Hour of Day", ylabel="MAE (kW)")

    colors = [DIM, YELLOW, GREEN, TEAL]
    for (name, pred), color in zip(pred_dict.items(), colors):
        hourly_mae = np.abs(pred.values - Y_test.values).mean(axis=0)
        ax.plot(range(24), hourly_mae, color=color,
                linewidth=2.0, label=name, marker="o", markersize=4)

    ax.set_xticks(range(24))
    ax.set_xticklabels(HLABELS, rotation=45, ha="right", fontsize=7.5)
    ax.legend(labelcolor=WHITE, fontsize=9)
    ax.axvspan(8, 18, color=ORANGE, alpha=0.05, label="Peak hours")

    plt.tight_layout()
    plt.savefig(save, dpi=150, bbox_inches="tight", facecolor=BG)
    plt.close()
    print(f"  Saved: {save}")


# ══════════════════════════════════════════════════════════════════════════════
# PLOT 7 — Model: Error Heatmap by Hour × Day-of-Week
# ══════════════════════════════════════════════════════════════════════════════

def plot_error_heatmap(Y_test: pd.DataFrame,
                       pred_xgb: pd.DataFrame,
                       save: str = "plot7_error_heatmap.png"):
    """
    Average signed error (predicted - actual) by hour and day-of-week.
    Blue = underestimate, Red = overestimate.
    Systematic patterns here reveal what the model is still missing.
    """
    err = pred_xgb.values - Y_test.values
    err_df = pd.DataFrame(err, index=Y_test.index, columns=HOURS)
    err_df["dow"] = err_df.index.dayofweek

    heatmap = err_df.groupby("dow")[HOURS].mean()
    heatmap.index = ["Mon","Tue","Wed","Thu","Fri","Sat","Sun"]

    fig, ax = plt.subplots(figsize=(14, 4), facecolor=BG)
    sax(ax, "XGBoost: Average Signed Error by Hour × Day  (kW)\n"
            "Blue = model underestimates  ·  Red = model overestimates",
        xlabel="Hour of Day", ylabel="")

    vmax = np.abs(heatmap.values).max()
    im   = ax.imshow(heatmap.values, aspect="auto",
                     cmap="RdBu_r", vmin=-vmax, vmax=vmax,
                     interpolation="nearest")
    cbar = plt.colorbar(im, ax=ax, pad=0.01)
    cbar.set_label("kW error", color=DIM, fontsize=8.5)
    cbar.ax.tick_params(colors=DIM, labelsize=8)

    ax.set_xticks(range(0, 24, 2))
    ax.set_xticklabels([HLABELS[h] for h in range(0, 24, 2)],
                       rotation=30, ha="right")
    ax.set_yticks(range(7))
    ax.set_yticklabels(["Mon","Tue","Wed","Thu","Fri","Sat","Sun"],
                       color=WHITE, fontsize=9)

    # Annotate cells with significant errors
    for row in range(7):
        for col in range(24):
            val = heatmap.values[row, col]
            if abs(val) > vmax * 0.5:
                ax.text(col, row, f"{val:.0f}",
                        ha="center", va="center",
                        color="white", fontsize=6, fontweight="bold")

    plt.tight_layout()
    plt.savefig(save, dpi=150, bbox_inches="tight", facecolor=BG)
    plt.close()
    print(f"  Saved: {save}")


# ══════════════════════════════════════════════════════════════════════════════
# MAIN
# ══════════════════════════════════════════════════════════════════════════════

if __name__ == "__main__":
    print("=" * 60)
    print(" UH Mānoa Load Forecast — Step 4: Visualizations")
    print("=" * 60 + "\n")

    # Load all data
    profiles = pd.read_csv("profiles.csv",              index_col=0, parse_dates=True)
    hourly   = pd.read_csv("hourly_merged.csv",         index_col=0, parse_dates=True)
    Y_test   = pd.read_csv("Y_test.csv",                index_col=0, parse_dates=True)
    xgb_pred = pd.read_csv("predictions_xgb.csv",      index_col=0, parse_dates=True)
    rid_pred = pd.read_csv("predictions_ridge.csv",     index_col=0, parse_dates=True)
    per_pred = pd.read_csv("predictions_persistence.csv", index_col=0, parse_dates=True)
    mea_pred = pd.read_csv("predictions_mean.csv",      index_col=0, parse_dates=True)

    # Align all predictions to Y_test index
    per_pred = per_pred.reindex(Y_test.index)
    rid_pred = rid_pred.reindex(Y_test.index)
    xgb_pred = xgb_pred.reindex(Y_test.index)
    mea_pred = mea_pred.reindex(Y_test.index)

    print("Generating plots...\n")

    plot_heatmap(profiles)
    plot_dow_profiles(profiles)
    plot_load_vs_temp(hourly)
    plot_acf(hourly)
    plot_forecast_days(Y_test, xgb_pred, per_pred)

    plot_hourly_mae(Y_test, {
        "Persistence":  per_pred,
        "Mean Profile": mea_pred,
        "Ridge":        rid_pred,
        "XGBoost":      xgb_pred,
    })

    plot_error_heatmap(Y_test, xgb_pred)

    print("\nAll plots saved. Open the PNG files to view your results.")
