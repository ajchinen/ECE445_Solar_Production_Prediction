# UH Mānoa Substation Meters — Load Forecasting
## Multi-Meter Daily Profile Forecast  ·  FY2025

---

## Meters in This Dataset

| Meter ID | Mean kW | Peak kW | Notes |
|---|---|---|---|
| 5C03646 | 4,103 | 6,935 | Largest substation |
| 5A03646 | 3,435 | 4,689 | Steady baseload |
| 40073741 | 2,440 | 3,618 | Consistent load |
| 40073742 | 1,218 | 3,341 | 6.8% zeros — intermittent |
| 40073743 | 139 | 1,033 | 63% zeros — auxiliary |
| 5B03646 | ~0 | — | 100% zeros — SKIPPED |

---

## Project Structure

```
meter_forecast/
├── substations_kw_15_min_fy25.csv   ← your meter data
│
├── step1_pipeline.py     Load meters + fetch weather → per-meter profiles
├── step2_features.py     Build lag features + train/test split per meter
├── step3_train.py        Train 4 models per meter + evaluate
├── step4_visualize.py    Generate dashboards per meter + comparison
├── step5_forecast.py     Forecast any meter on any future date
│
├── meter_data/           All intermediate CSVs (auto-created)
├── models/               Trained XGBoost pkl files (auto-created)
├── plots/                All PNG outputs (auto-created)
└── README.md
```

---

## Setup

```bash
pip install pandas numpy matplotlib scikit-learn xgboost \
            openmeteo-requests requests-cache retry-requests scipy \
            geopandas
```

---

## Run Order

```bash
python step1_pipeline.py      # ~2 min (weather API fetch)
python step2_features.py      # ~30 sec
python step3_train.py         # ~10-20 min (5 meters × 24 models)
python step4_visualize.py     # ~1 min
python step5_forecast.py      # forecast tomorrow, all meters
```

---

## Forecast Commands

```bash
# Tomorrow, all active meters
python step5_forecast.py

# Specific meter, tomorrow
python step5_forecast.py --meter 5C03646

# Specific meter, specific date
python step5_forecast.py --meter 5C03646 --date 2025-06-15

# All meters, specific date
python step5_forecast.py --date 2025-06-15
```

---

## Output Files

After running all steps you will have:

```
plots/
├── 5C03646_dashboard.png        ← full diagnostic dashboard per meter
├── 5A03646_dashboard.png
├── 40073741_dashboard.png
├── 40073742_dashboard.png
├── 40073743_dashboard.png
├── meter_comparison.png         ← all meters overlaid on one chart
└── <meter_id>_forecast_<date>.png  ← from step 5

meter_data/
└── model_comparison_all.csv     ← metrics for all meters + all models
```

---

## Connecting to Holmes Hall (Building 1163)

Building 1163 (Holmes Hall) maps to `building_complex_id = 1163`
in the building_complex.csv translation file. To connect it to
a substation meter you need a panel schedule or meter-to-building
mapping that shows which of the 6 meter IDs serves Holmes Hall.
