"""
step4_visualize.py
==================
UH Mānoa Substation Meters — Multi-Meter Load Forecasting
----------------------------------------------------------
WHAT THIS FILE DOES:
  Generates diagnostic and results plots for every active meter.
  Creates one combined dashboard PNG per meter plus a cross-meter
  comparison chart.

  Per-meter plots (saved as <meter_id>_dashboard.png):
    Panel 1 — Full-year load heatmap
    Panel 2 — Average profile by day-of-week
    Panel 3 — Predicted vs actual (6 sample test days)
    Panel 4 — Hourly MAE comparison across 4 models
    Panel 5 — Signed error heatmap (hour × day-of-week)
    Panel 6 — Metrics summary cards

  Cross-meter plot:
    meter_comparison.png — mean kW profile for all meters overlaid
"""

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec
import warnings
warnings.filterwarnings("ignore")
import os
os.makedirs("plots", exist_ok=True)

BG, PANEL, GRID_C = "#0d1117", "#131920", "#1e2633"
WHITE, DIM  = "#e8eaf0", "#8892a4"
TEAL, ORANGE, YELLOW, GREEN, PURPLE = \
    "#00d4c8", "#ff6b35", "#ffd166", "#00c97a", "#b48ead"
HOURS   = [f"h{h:02d}" for h in range(24)]
HLABELS = [f"{h:02d}:00" for h in range(24)]

plt.rcParams.update({
    "figure.facecolor": BG, "axes.facecolor": PANEL,
    "axes.edgecolor": GRID_C, "axes.labelcolor": DIM,
    "text.color": WHITE, "xtick.color": DIM, "ytick.color": DIM,
    "grid.color": GRID_C, "grid.linewidth": 0.6,
    "grid.linestyle": "--", "legend.facecolor": PANEL,
    "legend.edgecolor": GRID_C, "font.family": "monospace",
})


def sax(ax, title="", xlabel="", ylabel=""):
    ax.set_facecolor(PANEL)
    for sp in ax.spines.values(): sp.set_edgecolor(GRID_C)
    ax.tick_params(colors=DIM, labelsize=8)
    ax.grid(True)
    if title:  ax.set_title(title, color=WHITE, fontsize=9,
                             fontweight="bold", loc="left", pad=6)
    if xlabel: ax.set_xlabel(xlabel, fontsize=8)
    if ylabel: ax.set_ylabel(ylabel, fontsize=8)


def meter_dashboard(meter_id: str):
    """Generate the full dashboard for one meter."""
    profiles  = pd.read_csv(f"meter_data/{meter_id}_profiles.csv",
                             index_col=0, parse_dates=True)
    Y_test    = pd.read_csv(f"meter_data/{meter_id}_Y_test.csv",
                             index_col=0, parse_dates=True)
    xgb_pred  = pd.read_csv(f"meter_data/{meter_id}_pred_xgb.csv",
                             index_col=0, parse_dates=True)
    rid_pred  = pd.read_csv(f"meter_data/{meter_id}_pred_ridge.csv",
                             index_col=0, parse_dates=True)
    per_pred  = pd.read_csv(f"meter_data/{meter_id}_pred_persist.csv",
                             index_col=0, parse_dates=True)
    mea_pred  = pd.read_csv(f"meter_data/{meter_id}_pred_mean.csv",
                             index_col=0, parse_dates=True)

    # Align predictions to Y_test
    for p in [per_pred, rid_pred, xgb_pred, mea_pred]:
        p = p.reindex(Y_test.index)

    fig = plt.figure(figsize=(18, 14), facecolor=BG)
    gs  = gridspec.GridSpec(3, 3, figure=fig,
                             hspace=0.45, wspace=0.35,
                             left=0.06, right=0.97,
                             top=0.91, bottom=0.07)

    # Header
    fig.text(0.06, 0.955,
             f"Substation Meter: {meter_id}  —  Daily Load Profile Forecast",
             color=WHITE, fontsize=14, fontweight="bold")
    mean_kw = profiles[HOURS].values.mean()
    peak_kw = profiles[HOURS].values.max()
    fig.text(0.06, 0.930,
             f"FY25  ·  Mean {mean_kw:,.0f} kW  ·  Peak {peak_kw:,.0f} kW  ·  XGBoost (24 models)",
             color=DIM, fontsize=9)

    # ── Panel 1: Heatmap ───────────────────────────────────────────────────
    ax1 = fig.add_subplot(gs[0, :2])
    sax(ax1, "Full-year load heatmap  [kW]")
    data = profiles[HOURS].values
    im   = ax1.imshow(data, aspect="auto", cmap="YlOrRd",
                      interpolation="nearest",
                      extent=[-0.5, 23.5, len(data)+0.5, 0.5])
    cbar = plt.colorbar(im, ax=ax1, pad=0.01, shrink=0.85)
    cbar.ax.tick_params(colors=DIM, labelsize=7)
    cbar.set_label("kW", color=DIM, fontsize=8)
    ax1.set_xticks(range(0, 24, 2))
    ax1.set_xticklabels([HLABELS[h] for h in range(0, 24, 2)],
                         rotation=30, ha="right")
    tick_pos = list(range(0, len(profiles), 30))
    tick_lab = [profiles.index[i].strftime("%b %d") for i in tick_pos]
    ax1.set_yticks([p+1 for p in tick_pos])
    ax1.set_yticklabels(tick_lab, fontsize=7)

    # ── Panel 2: Day-of-week profiles ─────────────────────────────────────
    ax2 = fig.add_subplot(gs[0, 2])
    sax(ax2, "Avg profile by day-of-week", ylabel="kW")
    colors_dow = [TEAL, TEAL, TEAL, TEAL, YELLOW, ORANGE, PURPLE]
    dow_names  = ["Mon","Tue","Wed","Thu","Fri","Sat","Sun"]
    for dow in range(7):
        mask    = profiles.index.dayofweek == dow
        profile = profiles[mask][HOURS].mean()
        ax2.plot(range(24), profile.values,
                 color=colors_dow[dow], linewidth=1.5,
                 label=dow_names[dow], alpha=0.85)
    ax2.set_xticks(range(0, 24, 6))
    ax2.set_xticklabels([HLABELS[h] for h in range(0, 24, 6)],
                         rotation=30, ha="right")
    ax2.legend(labelcolor=WHITE, fontsize=7, loc="upper left",
               ncol=2)

    # ── Panel 3: Predicted vs actual (6 test days) ────────────────────────
    axes3 = [fig.add_subplot(gs[1, i]) for i in range(3)]
    indices = np.linspace(0, len(Y_test)-1, 6, dtype=int)
    for i, (ax, idx) in enumerate(zip(axes3 * 2, indices)):
        if i >= 3:
            break
        date   = Y_test.index[idx]
        actual = Y_test.iloc[idx].values
        xgb    = xgb_pred.reindex(Y_test.index).iloc[idx].values
        pers   = per_pred.reindex(Y_test.index).iloc[idx].values
        mae    = np.abs(xgb - actual).mean()
        sax(ax, f"{date.strftime('%b %d')} ({date.strftime('%a')})",
            ylabel="kW")
        ax.fill_between(range(24), xgb*0.95, xgb*1.05,
                        color=TEAL, alpha=0.12)
        ax.plot(range(24), pers,   color=DIM,    linewidth=1.2,
                linestyle=":", label="Persist")
        ax.plot(range(24), actual, color=ORANGE,  linewidth=2.0,
                label="Actual")
        ax.plot(range(24), xgb,    color=TEAL,    linewidth=2.0,
                linestyle="--", label=f"XGB MAE={mae:.0f}")
        ax.set_xticks(range(0, 24, 6))
        ax.set_xticklabels([HLABELS[h] for h in range(0, 24, 6)],
                            rotation=30, ha="right")
        ax.legend(labelcolor=WHITE, fontsize=6.5, loc="upper left")

    # ── Panel 4: Hourly MAE ────────────────────────────────────────────────
    ax4 = fig.add_subplot(gs[2, :2])
    sax(ax4, "Hourly MAE by model — test set", ylabel="MAE (kW)")
    pred_dict = {
        "Persistence":  per_pred.reindex(Y_test.index),
        "Mean Profile": mea_pred.reindex(Y_test.index),
        "Ridge":        rid_pred.reindex(Y_test.index),
        "XGBoost":      xgb_pred.reindex(Y_test.index),
    }
    colors_m = [DIM, YELLOW, GREEN, TEAL]
    for (name, pred), color in zip(pred_dict.items(), colors_m):
        if pred is None or pred.isnull().all().all():
            continue
        hourly_mae = np.abs(pred.values - Y_test.values).mean(axis=0)
        ax4.plot(range(24), hourly_mae, color=color,
                 linewidth=1.8, label=name, marker="o", markersize=3)
    ax4.set_xticks(range(24))
    ax4.set_xticklabels(HLABELS, rotation=45, ha="right", fontsize=6.5)
    ax4.legend(labelcolor=WHITE, fontsize=8)

    # ── Panel 5: Error heatmap ─────────────────────────────────────────────
    ax5 = fig.add_subplot(gs[2, 2])
    sax(ax5, "XGB signed error (hour × day)")
    err_df       = pd.DataFrame(
        xgb_pred.reindex(Y_test.index).values - Y_test.values,
        index=Y_test.index, columns=HOURS
    )
    err_df["dow"] = err_df.index.dayofweek
    heatmap       = err_df.groupby("dow")[HOURS].mean()
    heatmap.index = ["Mon","Tue","Wed","Thu","Fri","Sat","Sun"]
    vmax = max(abs(heatmap.values).max(), 1)
    im5  = ax5.imshow(heatmap.values, aspect="auto",
                      cmap="RdBu_r", vmin=-vmax, vmax=vmax,
                      interpolation="nearest")
    cbar5 = plt.colorbar(im5, ax=ax5, pad=0.02)
    cbar5.ax.tick_params(colors=DIM, labelsize=7)
    cbar5.set_label("kW", color=DIM, fontsize=7)
    ax5.set_xticks(range(0, 24, 4))
    ax5.set_xticklabels([HLABELS[h] for h in range(0, 24, 4)],
                         rotation=30, ha="right", fontsize=7)
    ax5.set_yticks(range(7))
    ax5.set_yticklabels(heatmap.index, color=WHITE, fontsize=8)

    save = f"plots/{meter_id}_dashboard.png"
    plt.savefig(save, dpi=140, bbox_inches="tight", facecolor=BG)
    plt.close()
    print(f"  Saved: {save}")


def plot_meter_comparison(meter_ids: list):
    """Overlay mean weekday profiles for all meters on one chart."""
    fig, axes = plt.subplots(1, 2, figsize=(14, 5), facecolor=BG)

    colors = [TEAL, ORANGE, YELLOW, GREEN, PURPLE, DIM]

    for ax, day_type, title in zip(
        axes,
        [lambda x: x < 5, lambda x: x >= 5],
        ["Weekday average profile — all meters",
         "Weekend average profile — all meters"]
    ):
        sax(ax, title, ylabel="Load (kW)")
        for (mid, color) in zip(meter_ids, colors):
            profiles = pd.read_csv(f"meter_data/{mid}_profiles.csv",
                                    index_col=0, parse_dates=True)
            mask    = day_type(profiles.index.dayofweek)
            profile = profiles[mask][HOURS].mean()
            ax.plot(range(24), profile.values,
                    color=color, linewidth=2.0, label=mid, alpha=0.85)
        ax.set_xticks(range(0, 24, 3))
        ax.set_xticklabels([HLABELS[h] for h in range(0, 24, 3)],
                            rotation=30, ha="right")
        ax.legend(labelcolor=WHITE, fontsize=8)

    save = "plots/meter_comparison.png"
    plt.tight_layout()
    plt.savefig(save, dpi=140, bbox_inches="tight", facecolor=BG)
    plt.close()
    print(f"  Saved: {save}")


# ══════════════════════════════════════════════════════════════════════════════
# MAIN
# ══════════════════════════════════════════════════════════════════════════════

if __name__ == "__main__":
    print("=" * 60)
    print(" UH Mānoa Substation Meters — Step 4: Visualizations")
    print("=" * 60 + "\n")

    meter_ids = pd.read_csv("meter_data/active_meters.csv",
                             header=None)[0].tolist()

    print("── Per-meter dashboards ────────────────────────────────────")
    for meter_id in meter_ids:
        meter_dashboard(meter_id)

    print("\n── Cross-meter comparison ──────────────────────────────────")
    plot_meter_comparison(meter_ids)

    print("\nAll plots saved to plots/ folder.")
    print("\n  → Run step5_forecast.py --meter <id> --date <YYYY-MM-DD>")
