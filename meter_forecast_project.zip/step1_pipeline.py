"""
step1_pipeline.py
=================
UH Mānoa Substation Meters — Multi-Meter Load Forecasting
----------------------------------------------------------
WHAT THIS FILE DOES:
  1. Loads the 6-meter substation CSV (substations_kw_15_min_fy25.csv)
  2. Validates and cleans each meter individually
  3. Fetches one full year of hourly weather from Open-Meteo (free, no key)
  4. Merges load + weather for every meter
  5. Reshapes each meter into a daily profile matrix [365 days × 24 hours]
  6. Skips meters that are mostly zeros (no meaningful signal to forecast)
  7. Saves one profiles CSV and one features CSV per active meter

METERS IN THIS FILE:
  5C03646   — largest substation   (~4,100 kW mean)
  5A03646   — steady baseload      (~3,400 kW mean)
  40073741  — consistent load      (~2,400 kW mean)
  40073742  — variable/intermittent (~1,200 kW mean, 6.8% zeros)
  40073743  — auxiliary/backup     (~139 kW mean,  63% zeros)
  5B03646   — standby feed         (100% zeros — skipped)

RUN THIS FIRST before any other step.
"""

import pandas as pd
import numpy as np
import openmeteo_requests
import requests_cache
from retry_requests import retry
import os
import warnings
warnings.filterwarnings("ignore")

# ── Configuration ──────────────────────────────────────────────────────────────
METER_CSV   = "substations_kw_15_min_fy25.csv"
START_DATE  = "2024-07-01"
END_DATE    = "2025-06-30"
CAMPUS_LAT  =  21.2969
CAMPUS_LON  = -157.8171
TIMEZONE    = "Pacific/Honolulu"

# Skip any meter where more than this fraction of readings are zero
# 5B03646 is 100% zeros — no signal to forecast
ZERO_THRESHOLD = 0.90

os.makedirs("meter_data", exist_ok=True)


# ══════════════════════════════════════════════════════════════════════════════
# STEP 1A — Load & Validate All Meters
# ══════════════════════════════════════════════════════════════════════════════

def load_all_meters(filepath: str) -> dict:
    """
    Load the multi-meter CSV and split into one Series per meter.

    Returns
    -------
    dict of {meter_id: pd.Series}  — hourly kW indexed by timestamp
    Only includes meters that pass the zero-reading threshold.
    """
    print("── Loading meter data ──────────────────────────────────────")
    df = pd.read_csv(filepath, parse_dates=["datetime"])
    df = df.sort_values(["meter_id", "datetime"])

    meter_ids = df["meter_id"].unique()
    print(f"  Found {len(meter_ids)} meters: {list(meter_ids)}\n")

    meters = {}
    for mid in meter_ids:
        sub = df[df["meter_id"] == mid].set_index("datetime")["kw"]

        # Resample 15-min → hourly (mean of 4 readings)
        hourly = sub.resample("h").mean()

        # Check zero fraction
        zero_frac = (hourly == 0).mean()

        # Interpolate short gaps
        n_missing = hourly.isna().sum()
        if n_missing > 0:
            hourly = hourly.interpolate(method="linear", limit=3)

        if zero_frac > ZERO_THRESHOLD:
            print(f"  ✗  {mid}  SKIPPED — {zero_frac*100:.0f}% zero readings "
                  f"(no meaningful load signal)")
            continue

        print(f"  ✓  {mid}  {len(hourly):,} hourly records  "
              f"| mean {hourly.mean():.0f} kW  "
              f"| max {hourly.max():.0f} kW  "
              f"| {zero_frac*100:.1f}% zeros")
        meters[mid] = hourly

    print(f"\n  → {len(meters)} meters will be modelled\n")
    return meters


# ══════════════════════════════════════════════════════════════════════════════
# STEP 1B — Fetch Weather (once, shared across all meters)
# ══════════════════════════════════════════════════════════════════════════════

def fetch_weather(start: str, end: str) -> pd.DataFrame:
    """
    Pull hourly historical weather for UH Mānoa from Open-Meteo.
    Weather is the same for all meters — fetch once and reuse.

    Returns
    -------
    pd.DataFrame indexed by hourly timestamp
    """
    print("── Fetching weather from Open-Meteo ───────────────────────")

    cache   = requests_cache.CachedSession(".weather_cache", expire_after=-1)
    session = retry(cache, retries=5, backoff_factor=0.3)
    om      = openmeteo_requests.Client(session=session)

    params = {
        "latitude":   CAMPUS_LAT,
        "longitude":  CAMPUS_LON,
        "start_date": start,
        "end_date":   end,
        "hourly": [
            "temperature_2m",
            "relative_humidity_2m",
            "dew_point_2m",
            "shortwave_radiation",
            "wind_speed_10m",
            "cloud_cover",
            "precipitation",
            "et0_fao_evapotranspiration",
        ],
        "temperature_unit": "fahrenheit",
        "wind_speed_unit":  "mph",
        "timezone":          TIMEZONE,
    }

    resp   = om.weather_api(
        "https://archive-api.open-meteo.com/v1/archive", params=params
    )[0]
    hourly = resp.Hourly()

    col_names = [
        "temp_f", "humidity_pct", "dew_point_f",
        "solar_wm2", "wind_mph", "cloud_pct",
        "precip_mm", "et0_mm",
    ]

    timestamps = pd.date_range(
        start     = pd.to_datetime(hourly.Time(),    unit="s", utc=True),
        end       = pd.to_datetime(hourly.TimeEnd(), unit="s", utc=True),
        freq      = pd.Timedelta(seconds=hourly.Interval()),
        inclusive = "left"
    ).tz_convert(TIMEZONE).tz_localize(None)

    weather = pd.DataFrame(
        {n: hourly.Variables(i).ValuesAsNumpy()
         for i, n in enumerate(col_names)},
        index = timestamps
    )

    # Engineered weather features
    T, RH = weather["temp_f"], weather["humidity_pct"]
    weather["cdh"] = (T - 65).clip(lower=0)
    weather["heat_index_f"] = (
        -42.379 + 2.04901523*T + 10.14333127*RH
        - 0.22475541*T*RH - 0.00683783*T**2
        - 0.05481717*RH**2 + 0.00122874*T**2*RH
        + 0.00085282*T*RH**2 - 0.00000199*T**2*RH**2
    )
    weather["heat_index_f"] = weather[["temp_f","heat_index_f"]].max(axis=1)

    hour  = weather.index.hour
    month = weather.index.month
    weather["hour_sin"]  = np.sin(2*np.pi*hour/24)
    weather["hour_cos"]  = np.cos(2*np.pi*hour/24)
    weather["month_sin"] = np.sin(2*np.pi*month/12)
    weather["month_cos"] = np.cos(2*np.pi*month/12)

    print(f"  ✓  {len(weather):,} hourly records fetched")
    print(f"  ✓  Temp range: {weather.temp_f.min():.1f}–{weather.temp_f.max():.1f} °F")
    print(f"  ✓  Max solar : {weather.solar_wm2.max():.0f} W/m²\n")

    return weather


# ══════════════════════════════════════════════════════════════════════════════
# STEP 1C — Reshape Each Meter Into Daily Profiles
# ══════════════════════════════════════════════════════════════════════════════

def reshape_meter(meter_id: str,
                  hourly_kw: pd.Series,
                  weather:   pd.DataFrame,
                  min_hours: int = 20) -> tuple:
    """
    For one meter: merge load + weather, reshape into daily profile matrix.

    Parameters
    ----------
    meter_id  : string ID for labeling
    hourly_kw : hourly kW Series for this meter
    weather   : shared hourly weather DataFrame
    min_hours : minimum valid hours per day to keep

    Returns
    -------
    profiles : pd.DataFrame [N_days × 24]  — kW at each hour (TARGET)
    daily_X  : pd.DataFrame [N_days × features] — daily feature summaries
    """
    # Merge load + weather
    merged = hourly_kw.to_frame("kw").join(weather, how="inner")

    df = merged.copy()
    df["date"] = df.index.date
    df["hour"] = df.index.hour

    # ── Profile matrix ──────────────────────────────────────────────────────
    profiles = (
        df.pivot(index="date", columns="hour", values="kw")
          .rename(columns=lambda h: f"h{h:02d}")
    )
    profiles.index = pd.to_datetime(profiles.index)

    complete = profiles.notna().sum(axis=1) >= min_hours
    profiles = profiles[complete].interpolate(axis=1, limit=2)

    # ── Daily feature summaries ─────────────────────────────────────────────
    HOURS = [f"h{h:02d}" for h in range(24)]

    daily_X = df.groupby("date").agg(
        temp_mean     = ("temp_f",       "mean"),
        temp_max      = ("temp_f",       "max"),
        temp_min      = ("temp_f",       "min"),
        temp_range    = ("temp_f",       lambda x: x.max() - x.min()),
        humidity_mean = ("humidity_pct", "mean"),
        dew_point_max = ("dew_point_f",  "max"),
        solar_total   = ("solar_wm2",    "sum"),
        solar_peak    = ("solar_wm2",    "max"),
        wind_mean     = ("wind_mph",     "mean"),
        cloud_mean    = ("cloud_pct",    "mean"),
        precip_total  = ("precip_mm",    "sum"),
        cdh_total     = ("cdh",          "sum"),
        heat_idx_max  = ("heat_index_f", "max"),
        et0_total     = ("et0_mm",       "sum"),
    )
    daily_X.index = pd.to_datetime(daily_X.index)

    # Calendar features
    daily_X["day_of_week"] = daily_X.index.dayofweek
    daily_X["month"]       = daily_X.index.month
    daily_X["is_weekend"]  = (daily_X["day_of_week"] >= 5).astype(int)
    daily_X["is_friday"]   = (daily_X["day_of_week"] == 4).astype(int)
    daily_X["is_monday"]   = (daily_X["day_of_week"] == 0).astype(int)

    # UH holidays FY25
    uh_holidays = pd.to_datetime([
        "2024-07-04","2024-08-16","2024-09-02","2024-10-14",
        "2024-11-11","2024-11-28","2024-11-29",
        "2024-12-23","2024-12-24","2024-12-25","2024-12-26",
        "2024-12-27","2024-12-30","2024-12-31",
        "2025-01-01","2025-01-02","2025-01-03","2025-01-20",
        "2025-02-17","2025-03-26","2025-04-18",
        "2025-05-26","2025-06-11",
    ])
    daily_X["is_holiday"] = daily_X.index.isin(uh_holidays).astype(int)

    fy_start = pd.Timestamp("2024-07-01")
    daily_X["fy_week"] = np.maximum(0, (daily_X.index - fy_start).days // 7)

    doy = daily_X.index.dayofyear
    daily_X["doy_sin"] = np.sin(2*np.pi*doy/365)
    daily_X["doy_cos"] = np.cos(2*np.pi*doy/365)

    # Align
    common   = profiles.index.intersection(daily_X.index)
    profiles = profiles.loc[common]
    daily_X  = daily_X.loc[common]

    print(f"  {meter_id:<12}  {len(profiles)} days  "
          f"| mean {profiles.values.mean():.0f} kW  "
          f"| peak {profiles.values.max():.0f} kW")

    return profiles, daily_X


# ══════════════════════════════════════════════════════════════════════════════
# MAIN
# ══════════════════════════════════════════════════════════════════════════════

if __name__ == "__main__":
    print("=" * 60)
    print(" UH Mānoa Substation Meters — Step 1: Data Pipeline")
    print("=" * 60 + "\n")

    # 1. Load all meters
    meters = load_all_meters(METER_CSV)

    # 2. Fetch weather once (shared by all meters)
    weather = fetch_weather(START_DATE, END_DATE)

    # 3. Reshape each meter into daily profiles
    print("── Reshaping meters into daily profiles ───────────────────")
    meter_ids_active = []

    for meter_id, hourly_kw in meters.items():
        profiles, daily_X = reshape_meter(meter_id, hourly_kw, weather)

        # Save per-meter files into meter_data/ folder
        profiles.to_csv(f"meter_data/{meter_id}_profiles.csv")
        daily_X.to_csv(f"meter_data/{meter_id}_features.csv")
        meter_ids_active.append(meter_id)

    # Save the list of active meters for downstream steps
    pd.Series(meter_ids_active).to_csv("meter_data/active_meters.csv",
                                        index=False, header=False)

    print(f"\n── Saved files ─────────────────────────────────────────────")
    print(f"  meter_data/<meter_id>_profiles.csv  — daily profile matrix")
    print(f"  meter_data/<meter_id>_features.csv  — daily feature summaries")
    print(f"  meter_data/active_meters.csv        — list of modelled meters")
    print(f"\n  Active meters: {meter_ids_active}")
    print(f"\n  → Run step2_features.py next")
