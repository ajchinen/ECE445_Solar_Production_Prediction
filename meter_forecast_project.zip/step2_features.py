"""
step2_features.py
=================
UH Mānoa Substation Meters — Multi-Meter Load Forecasting
----------------------------------------------------------
WHAT THIS FILE DOES:
  Reads per-meter profiles from step 1 and builds the full feature
  matrix for each meter — lag profiles, rolling averages, calendar
  features — then performs a temporal train/test split.

  Each meter gets its own X_train, X_test, Y_train, Y_test because
  their load patterns are completely different:
    5C03646  — large substation with strong daily peaks
    40073742 — intermittent load, harder to forecast
    40073743 — mostly zero, spike-based behavior

  The feature set is identical across meters so the same model
  architecture works for all of them.
"""

import pandas as pd
import numpy as np
from sklearn.decomposition import PCA
from sklearn.preprocessing import StandardScaler
import os
import warnings
warnings.filterwarnings("ignore")

HOURS = [f"h{h:02d}" for h in range(24)]
os.makedirs("meter_data", exist_ok=True)


# ══════════════════════════════════════════════════════════════════════════════
# FEATURE BUILDER
# ══════════════════════════════════════════════════════════════════════════════

def build_features(profiles: pd.DataFrame,
                   daily_X:  pd.DataFrame) -> tuple:
    """
    Build the full feature matrix for one meter.

    Features added on top of daily weather + calendar summaries:
      - Lag-1  : yesterday's full 24-hour load profile
      - Lag-7  : same weekday last week's profile
      - Lag-2  : two days ago profile
      - Roll-7 : 7-day rolling mean profile (recent typical shape)
      - Rolling weather trends (7-day temp mean, CDH mean)

    Parameters
    ----------
    profiles : [N_days × 24] daily load profiles
    daily_X  : [N_days × features] weather + calendar per day

    Returns
    -------
    X : complete feature DataFrame
    Y : target profile DataFrame [N_days × 24]
    """
    frames = [daily_X.copy()]

    # ── Lag 1: yesterday ─────────────────────────────────────────────────────
    lag1 = profiles.shift(1)
    lag1.columns = [f"lag1_{c}" for c in HOURS]
    frames.append(lag1)
    frames.append(pd.DataFrame({
        "lag1_peak_kw"   : lag1.max(axis=1),
        "lag1_mean_kw"   : lag1.mean(axis=1),
        "lag1_min_kw"    : lag1.min(axis=1),
        "lag1_peak_hour" : lag1.apply(
            lambda r: float(np.argmax(r.values)) if r.notna().any() else np.nan,
            axis=1),
        "lag1_daily_kwh" : lag1.sum(axis=1),
    }, index=profiles.index))

    # ── Lag 7: same weekday last week ────────────────────────────────────────
    lag7 = profiles.shift(7)
    lag7.columns = [f"lag7_{c}" for c in HOURS]
    frames.append(lag7)
    frames.append(pd.DataFrame({
        "lag7_peak_kw"   : lag7.max(axis=1),
        "lag7_mean_kw"   : lag7.mean(axis=1),
        "lag7_daily_kwh" : lag7.sum(axis=1),
    }, index=profiles.index))

    # ── Lag 2: two days ago ──────────────────────────────────────────────────
    lag2 = profiles.shift(2)
    lag2.columns = [f"lag2_{c}" for c in HOURS]
    frames.append(lag2)

    # ── Rolling 7-day mean profile ───────────────────────────────────────────
    roll7 = profiles.shift(1).rolling(window=7, min_periods=3).mean()
    roll7.columns = [f"roll7_{c}" for c in HOURS]
    frames.append(roll7)
    frames.append(pd.DataFrame({
        "roll7_peak_kw" : roll7.max(axis=1),
        "roll7_mean_kw" : roll7.mean(axis=1),
    }, index=profiles.index))

    # ── Rolling weather stats ────────────────────────────────────────────────
    frames.append(pd.DataFrame({
        "roll7_temp_mean": daily_X["temp_mean"].shift(1).rolling(7).mean(),
        "roll7_cdh_mean" : daily_X["cdh_total"].shift(1).rolling(7).mean(),
    }, index=profiles.index))

    # ── One-hot encode day of week + month ───────────────────────────────────
    dow_dummies   = pd.get_dummies(daily_X["day_of_week"],
                                   prefix="dow", dtype=float)
    month_dummies = pd.get_dummies(daily_X["month"],
                                   prefix="month", dtype=float)
    frames.extend([dow_dummies, month_dummies])

    # Cyclical encodings
    frames.append(pd.DataFrame({
        "dow_sin"  : np.sin(2*np.pi*daily_X["day_of_week"]/7),
        "dow_cos"  : np.cos(2*np.pi*daily_X["day_of_week"]/7),
        "month_sin": np.sin(2*np.pi*daily_X["month"]/12),
        "month_cos": np.cos(2*np.pi*daily_X["month"]/12),
    }, index=daily_X.index))

    # ── Combine ──────────────────────────────────────────────────────────────
    X = pd.concat(frames, axis=1)
    Y = profiles.copy()

    # Drop first 7 rows (lag-7 unavailable)
    X = X.iloc[7:]
    Y = Y.iloc[7:]

    # Remove NaN rows
    valid = X.dropna().index.intersection(Y.dropna(how="any").index)
    X, Y  = X.loc[valid], Y.loc[valid]

    return X, Y


# ══════════════════════════════════════════════════════════════════════════════
# TEMPORAL SPLIT
# ══════════════════════════════════════════════════════════════════════════════

def temporal_split(X, Y, test_days=60):
    """
    Reserve the last `test_days` days for testing.
    Always split by time — never randomly.
    """
    n     = len(X)
    split = n - test_days
    return X.iloc[:split], X.iloc[split:], Y.iloc[:split], Y.iloc[split:]


# ══════════════════════════════════════════════════════════════════════════════
# PCA SUMMARY
# ══════════════════════════════════════════════════════════════════════════════

def summarise_pca(meter_id: str, Y_train: pd.DataFrame):
    """
    Run PCA on training profiles and print how many components
    capture 95% of the variance. Useful diagnostic per meter.
    """
    scaler = StandardScaler()
    pca    = PCA()
    pca.fit(scaler.fit_transform(Y_train.values))
    cumvar = pca.explained_variance_ratio_.cumsum()
    n95    = int(np.searchsorted(cumvar, 0.95)) + 1
    n99    = int(np.searchsorted(cumvar, 0.99)) + 1
    print(f"  {meter_id:<12}  {n95} components → 95% variance  "
          f"| {n99} components → 99% variance")


# ══════════════════════════════════════════════════════════════════════════════
# MAIN
# ══════════════════════════════════════════════════════════════════════════════

if __name__ == "__main__":
    print("=" * 60)
    print(" UH Mānoa Substation Meters — Step 2: Feature Engineering")
    print("=" * 60 + "\n")

    # Load active meter list
    meter_ids = pd.read_csv("meter_data/active_meters.csv",
                             header=None)[0].tolist()
    print(f"  Processing {len(meter_ids)} meters: {meter_ids}\n")

    print("── Building feature matrices ───────────────────────────────")
    for meter_id in meter_ids:
        profiles = pd.read_csv(f"meter_data/{meter_id}_profiles.csv",
                                index_col=0, parse_dates=True)
        daily_X  = pd.read_csv(f"meter_data/{meter_id}_features.csv",
                                index_col=0, parse_dates=True)

        X, Y = build_features(profiles, daily_X)

        X_train, X_test, Y_train, Y_test = temporal_split(X, Y, test_days=60)

        # Save splits
        X_train.to_csv(f"meter_data/{meter_id}_X_train.csv")
        X_test.to_csv( f"meter_data/{meter_id}_X_test.csv")
        Y_train.to_csv(f"meter_data/{meter_id}_Y_train.csv")
        Y_test.to_csv( f"meter_data/{meter_id}_Y_test.csv")

        print(f"  {meter_id:<12}  "
              f"train {len(X_train)} days "
              f"({X_train.index.min().date()} → {X_train.index.max().date()})  "
              f"| test {len(X_test)} days  "
              f"| {X_train.shape[1]} features")

    print()
    print("── PCA profile structure per meter ─────────────────────────")
    for meter_id in meter_ids:
        Y_train = pd.read_csv(f"meter_data/{meter_id}_Y_train.csv",
                               index_col=0, parse_dates=True)
        summarise_pca(meter_id, Y_train)

    print(f"\n── Saved files ─────────────────────────────────────────────")
    print(f"  meter_data/<meter_id>_X_train/test.csv")
    print(f"  meter_data/<meter_id>_Y_train/test.csv")
    print(f"\n  → Run step3_train.py next")
