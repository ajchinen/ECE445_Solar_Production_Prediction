"""
step5_forecast.py
=================
UH Mānoa Substation Meters — Multi-Meter Load Forecasting
----------------------------------------------------------
WHAT THIS FILE DOES:
  Generates a 24-hour load profile forecast for a specific meter
  on a specific future date (up to 7 days ahead).

USAGE:
  # Forecast tomorrow for all active meters
  python step5_forecast.py

  # Forecast a specific meter
  python step5_forecast.py --meter 5C03646

  # Forecast a specific meter on a specific date
  python step5_forecast.py --meter 5C03646 --date 2025-06-15

  # Forecast all meters for a specific date
  python step5_forecast.py --date 2025-06-15
"""

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import pickle
import argparse
import openmeteo_requests
import requests_cache
from retry_requests import retry
from datetime import datetime, timedelta
import os
import warnings
warnings.filterwarnings("ignore")

CAMPUS_LAT = 21.2969
CAMPUS_LON = -157.8171
TIMEZONE   = "Pacific/Honolulu"
HOURS      = [f"h{h:02d}" for h in range(24)]
HLABELS    = [f"{h:02d}:00" for h in range(24)]

BG, PANEL, GRID_C = "#0d1117", "#131920", "#1e2633"
WHITE, DIM  = "#e8eaf0", "#8892a4"
TEAL, ORANGE, YELLOW = "#00d4c8", "#ff6b35", "#ffd166"

os.makedirs("plots", exist_ok=True)


# ══════════════════════════════════════════════════════════════════════════════
# FETCH FORECAST WEATHER
# ══════════════════════════════════════════════════════════════════════════════

def fetch_forecast_weather(target_date: str) -> pd.DataFrame:
    """Pull 7-day hourly weather forecast and return the target day only."""
    cache   = requests_cache.CachedSession(".weather_cache", expire_after=3600)
    session = retry(cache, retries=5, backoff_factor=0.3)
    om      = openmeteo_requests.Client(session=session)

    params = {
        "latitude":  CAMPUS_LAT, "longitude": CAMPUS_LON,
        "hourly": [
            "temperature_2m","relative_humidity_2m","dew_point_2m",
            "shortwave_radiation","wind_speed_10m","cloud_cover",
            "precipitation","et0_fao_evapotranspiration",
        ],
        "temperature_unit": "fahrenheit",
        "wind_speed_unit":  "mph",
        "timezone":          TIMEZONE,
        "forecast_days":     7,
    }

    resp   = om.weather_api("https://api.open-meteo.com/v1/forecast",
                             params=params)[0]
    hourly = resp.Hourly()

    col_names = ["temp_f","humidity_pct","dew_point_f",
                 "solar_wm2","wind_mph","cloud_pct","precip_mm","et0_mm"]

    timestamps = pd.date_range(
        start     = pd.to_datetime(hourly.Time(),    unit="s", utc=True),
        end       = pd.to_datetime(hourly.TimeEnd(), unit="s", utc=True),
        freq      = pd.Timedelta(seconds=hourly.Interval()),
        inclusive = "left"
    ).tz_convert(TIMEZONE).tz_localize(None)

    df = pd.DataFrame(
        {n: hourly.Variables(i).ValuesAsNumpy()
         for i, n in enumerate(col_names)},
        index=timestamps
    )

    # Engineer features
    T, RH = df["temp_f"], df["humidity_pct"]
    df["cdh"] = (T - 65).clip(lower=0)
    df["heat_index_f"] = (
        -42.379 + 2.04901523*T + 10.14333127*RH
        - 0.22475541*T*RH - 0.00683783*T**2
        - 0.05481717*RH**2 + 0.00122874*T**2*RH
        + 0.00085282*T*RH**2 - 0.00000199*T**2*RH**2
    )
    df["heat_index_f"] = df[["temp_f","heat_index_f"]].max(axis=1)

    day_data = df[df.index.date == pd.to_datetime(target_date).date()]
    if len(day_data) == 0:
        raise ValueError(
            f"No forecast data for {target_date}. "
            "Open-Meteo only forecasts 7 days ahead."
        )
    return day_data


# ══════════════════════════════════════════════════════════════════════════════
# BUILD FEATURE ROW FOR FORECAST DAY
# ══════════════════════════════════════════════════════════════════════════════

def build_forecast_features(target_date: str,
                             weather_day: pd.DataFrame,
                             profiles:    pd.DataFrame,
                             X_train:     pd.DataFrame) -> pd.DataFrame:
    """Build the single feature row for the forecast day."""
    target_dt = pd.to_datetime(target_date)
    available = profiles[profiles.index < target_dt]

    if len(available) == 0:
        raise ValueError("No historical profiles available before target date.")

    row = {
        "temp_mean"     : weather_day["temp_f"].mean(),
        "temp_max"      : weather_day["temp_f"].max(),
        "temp_min"      : weather_day["temp_f"].min(),
        "temp_range"    : weather_day["temp_f"].max() - weather_day["temp_f"].min(),
        "humidity_mean" : weather_day["humidity_pct"].mean(),
        "dew_point_max" : weather_day["dew_point_f"].max(),
        "solar_total"   : weather_day["solar_wm2"].sum(),
        "solar_peak"    : weather_day["solar_wm2"].max(),
        "wind_mean"     : weather_day["wind_mph"].mean(),
        "cloud_mean"    : weather_day["cloud_pct"].mean(),
        "precip_total"  : weather_day["precip_mm"].sum(),
        "cdh_total"     : weather_day["cdh"].sum(),
        "heat_idx_max"  : weather_day["heat_index_f"].max(),
        "et0_total"     : weather_day["et0_mm"].sum(),
    }

    dow = target_dt.dayofweek
    row.update({
        "day_of_week": dow, "month": target_dt.month,
        "is_weekend": int(dow >= 5), "is_friday": int(dow == 4),
        "is_monday": int(dow == 0), "is_holiday": 0,
        "fy_week": max(0, (target_dt - pd.Timestamp("2024-07-01")).days // 7),
        "doy_sin": np.sin(2*np.pi*target_dt.dayofyear/365),
        "doy_cos": np.cos(2*np.pi*target_dt.dayofyear/365),
    })

    # Lag features from historical profiles
    lag1 = available.iloc[-1]
    lag7_cands = available[available.index.dayofweek == dow]
    lag7 = lag7_cands.iloc[-1] if len(lag7_cands) > 0 else lag1
    lag2 = available.iloc[-2] if len(available) >= 2 else lag1

    for h in HOURS:
        row[f"lag1_{h}"] = float(lag1.get(h, 0))
        row[f"lag7_{h}"] = float(lag7.get(h, 0))
        row[f"lag2_{h}"] = float(lag2.get(h, 0))

    row.update({
        "lag1_peak_kw"   : float(lag1[HOURS].max()),
        "lag1_mean_kw"   : float(lag1[HOURS].mean()),
        "lag1_min_kw"    : float(lag1[HOURS].min()),
        "lag1_peak_hour" : float(np.argmax([lag1.get(h,0) for h in HOURS])),
        "lag1_daily_kwh" : float(lag1[HOURS].sum()),
        "lag7_peak_kw"   : float(lag7[HOURS].max()),
        "lag7_mean_kw"   : float(lag7[HOURS].mean()),
        "lag7_daily_kwh" : float(lag7[HOURS].sum()),
    })

    recent = available.iloc[-7:]
    roll7  = recent[HOURS].mean()
    for h in HOURS:
        row[f"roll7_{h}"] = float(roll7.get(h, 0))
    row.update({
        "roll7_peak_kw"  : float(roll7.max()),
        "roll7_mean_kw"  : float(roll7.mean()),
        "roll7_temp_mean": row["temp_mean"],
        "roll7_cdh_mean" : row["cdh_total"] / 24,
    })

    # One-hot + cyclical calendar
    for d in range(7):
        row[f"dow_{d}"] = int(dow == d)
    for m in range(1, 13):
        row[f"month_{m}"] = int(target_dt.month == m)
    row.update({
        "dow_sin"  : np.sin(2*np.pi*dow/7),
        "dow_cos"  : np.cos(2*np.pi*dow/7),
        "month_sin": np.sin(2*np.pi*target_dt.month/12),
        "month_cos": np.cos(2*np.pi*target_dt.month/12),
    })

    X = pd.DataFrame([row])
    for col in X_train.columns:
        if col not in X.columns:
            X[col] = 0.0
    return X[X_train.columns]


# ══════════════════════════════════════════════════════════════════════════════
# FORECAST ONE METER
# ══════════════════════════════════════════════════════════════════════════════

def forecast_meter(meter_id: str, target_date: str):
    """Run forecast for one meter on one date."""
    print(f"\n── {meter_id}  →  {target_date} ──────────────────────────")

    with open(f"models/{meter_id}_xgb.pkl", "rb") as f:
        xgb_models = pickle.load(f)

    profiles = pd.read_csv(f"meter_data/{meter_id}_profiles.csv",
                            index_col=0, parse_dates=True)
    X_train  = pd.read_csv(f"meter_data/{meter_id}_X_train.csv",
                            index_col=0, parse_dates=True)

    weather_day = fetch_forecast_weather(target_date)
    X           = build_forecast_features(target_date, weather_day,
                                           profiles, X_train)

    preds  = {h: float(xgb_models[h].predict(X.values)[0]) for h in HOURS}
    result = pd.Series(preds)

    peak_h = int(result.argmax())
    print(f"  Peak: {result.max():,.0f} kW @ {HLABELS[peak_h]}")
    print(f"  Mean: {result.mean():,.0f} kW")
    print(f"  Daily energy (approx): {result.sum():,.0f} kWh")

    # Plot
    fig, axes = plt.subplots(2, 1, figsize=(13, 7),
                              facecolor=BG,
                              gridspec_kw={"height_ratios": [3, 1]})

    ax = axes[0]
    ax.set_facecolor(PANEL)
    for sp in ax.spines.values(): sp.set_edgecolor(GRID_C)
    ax.tick_params(colors=DIM, labelsize=8)
    ax.grid(True, color=GRID_C, linewidth=0.5, linestyle="--")

    y     = result.values
    sigma = y * 0.05
    ax.fill_between(range(24), y-2*sigma, y+2*sigma,
                    color=TEAL, alpha=0.07, label="±2σ")
    ax.fill_between(range(24), y-sigma,   y+sigma,
                    color=TEAL, alpha=0.15, label="±1σ")
    ax.plot(range(24), y, color=TEAL, linewidth=2.5,
            label="Forecast (XGBoost)")
    ax.scatter(range(24), y, color=TEAL, s=28, zorder=5, alpha=0.8)

    ax.annotate(f"  Peak: {y[peak_h]:,.0f} kW",
                xy=(peak_h, y[peak_h]),
                xytext=(min(peak_h+2, 20), y[peak_h]+y[peak_h]*0.05),
                color=YELLOW, fontsize=9, fontweight="bold",
                arrowprops=dict(arrowstyle="->", color=YELLOW, lw=1.2),
                bbox=dict(facecolor=BG, edgecolor=YELLOW,
                          linewidth=1, boxstyle="round,pad=0.3"))

    ax.set_title(
        f"Meter {meter_id}  —  "
        f"{pd.to_datetime(target_date).strftime('%A, %B %d, %Y')}  "
        f"·  XGBoost Forecast",
        color=WHITE, fontsize=11, fontweight="bold", pad=10
    )
    ax.set_ylabel("Load (kW)", color=DIM, fontsize=9)
    ax.set_xlim(-0.5, 23.5)
    ax.set_xticks(range(24))
    ax.set_xticklabels(HLABELS, rotation=45, ha="right", fontsize=7.5)
    ax.legend(facecolor=PANEL, edgecolor=GRID_C,
              labelcolor=WHITE, fontsize=8.5)

    ax2 = axes[1]
    ax2.set_facecolor(PANEL)
    for sp in ax2.spines.values(): sp.set_edgecolor(GRID_C)
    ax2.tick_params(colors=DIM, labelsize=8)
    ax2.grid(True, color=GRID_C, linewidth=0.5, linestyle="--")
    ax3 = ax2.twinx()
    ax3.set_facecolor(PANEL)
    ax2.plot(range(24), weather_day["temp_f"].values,
             color=ORANGE, linewidth=1.8, label="Temp (°F)")
    ax3.fill_between(range(24), 0, weather_day["solar_wm2"].values,
                     color=YELLOW, alpha=0.2)
    ax3.plot(range(24), weather_day["solar_wm2"].values,
             color=YELLOW, linewidth=1.4, alpha=0.8, label="Solar W/m²")
    ax2.set_ylabel("Temp (°F)", color=ORANGE, fontsize=8)
    ax3.set_ylabel("Solar W/m²", color=YELLOW, fontsize=8)
    ax2.tick_params(axis="y", colors=ORANGE)
    ax3.tick_params(axis="y", colors=YELLOW)
    ax2.set_xlim(-0.5, 23.5)
    ax2.set_xticks(range(0, 24, 2))
    ax2.set_xticklabels([HLABELS[h] for h in range(0, 24, 2)],
                         rotation=30, ha="right", fontsize=7.5)

    save = f"plots/{meter_id}_forecast_{target_date}.png"
    plt.tight_layout()
    plt.savefig(save, dpi=150, bbox_inches="tight", facecolor=BG)
    plt.close()
    print(f"  Plot saved: {save}")

    return result


# ══════════════════════════════════════════════════════════════════════════════
# MAIN
# ══════════════════════════════════════════════════════════════════════════════

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--meter", type=str, default="all",
                        help="Meter ID or 'all' for every active meter")
    parser.add_argument("--date",  type=str,
                        default=(datetime.today() + timedelta(days=1))
                                 .strftime("%Y-%m-%d"),
                        help="Forecast date YYYY-MM-DD (default: tomorrow)")
    args = parser.parse_args()

    print("=" * 60)
    print(f" UH Mānoa Substation Meters — Step 5: Forecast")
    print(f" Date: {args.date}")
    print("=" * 60)

    meter_ids = pd.read_csv("meter_data/active_meters.csv",
                             header=None)[0].tolist()

    if args.meter != "all":
        if args.meter not in meter_ids:
            print(f"Error: meter '{args.meter}' not in active meters: {meter_ids}")
            exit(1)
        meter_ids = [args.meter]

    for meter_id in meter_ids:
        forecast_meter(meter_id, args.date)
