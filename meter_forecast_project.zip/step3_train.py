"""
step3_train.py
==============
UH Mānoa Substation Meters — Multi-Meter Load Forecasting
----------------------------------------------------------
WHAT THIS FILE DOES:
  Trains four models for EVERY active meter and evaluates each on
  the held-out test set. Saves trained XGBoost models for step 5.

  The same model progression is used for every meter:
    1. Persistence  — tomorrow = yesterday (baseline floor)
    2. Mean Profile — average by day-of-week (smart baseline)
    3. Ridge        — linear regression with regularization
    4. XGBoost      — gradient boosted trees (24 models per hour)

  Why train all four for every meter?
  Some meters (like 40073743, mostly zeros) may be better forecast
  by the mean profile than XGBoost because there's little signal.
  Running all four reveals which approach wins per meter.
"""

import pandas as pd
import numpy as np
import xgboost as xgb
from sklearn.linear_model import Ridge
from sklearn.multioutput import MultiOutputRegressor
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import Pipeline
import pickle
import os
import warnings
warnings.filterwarnings("ignore")

HOURS = [f"h{h:02d}" for h in range(24)]
os.makedirs("meter_data", exist_ok=True)
os.makedirs("models",     exist_ok=True)


# ══════════════════════════════════════════════════════════════════════════════
# EVALUATION
# ══════════════════════════════════════════════════════════════════════════════

def evaluate(Y_true: pd.DataFrame, Y_pred: pd.DataFrame) -> dict:
    """Compute profile-level metrics."""
    true = Y_true.values
    pred = Y_pred.values
    err  = pred - true

    mae  = float(np.abs(err).mean())
    rmse = float(np.sqrt((err**2).mean()))
    mape = float(np.abs(err / (true + 1e-6)).mean() * 100)

    peak_true     = true.max(axis=1)
    peak_pred     = pred.max(axis=1)
    peak_err      = float(np.abs(peak_pred - peak_true).mean())
    peak_time_err = float(
        np.abs(np.argmax(pred, axis=1) - np.argmax(true, axis=1)).mean()
    )
    energy_err    = float(
        np.abs((pred.sum(axis=1) - true.sum(axis=1)) /
               (true.sum(axis=1) + 1e-6)).mean() * 100
    )
    corrs     = [np.corrcoef(true[i], pred[i])[0,1]
                 for i in range(len(true))]
    profile_r = float(np.nanmean(corrs))

    return dict(mae=mae, rmse=rmse, mape=mape,
                peak_err=peak_err, peak_time_err=peak_time_err,
                energy_err=energy_err, profile_r=profile_r)


def wrap(preds, index):
    return pd.DataFrame(preds, index=index, columns=HOURS)


# ══════════════════════════════════════════════════════════════════════════════
# MODEL 1 — Persistence
# ══════════════════════════════════════════════════════════════════════════════

def predict_persistence(X_test):
    lag1_cols = [c for c in X_test.columns if c.startswith("lag1_h")]
    preds = X_test[lag1_cols].copy()
    preds.columns = HOURS
    return preds


# ══════════════════════════════════════════════════════════════════════════════
# MODEL 2 — Mean Profile
# ══════════════════════════════════════════════════════════════════════════════

def fit_mean_profile(X_train, Y_train):
    model = {}
    for dow in range(7):
        mask = X_train.index.dayofweek == dow
        model[dow] = Y_train[mask].mean().values if mask.sum() > 0 \
                     else Y_train.mean().values
    model["overall"] = Y_train.mean().values
    return model


def predict_mean_profile(model, X_test):
    preds = np.array([model.get(dow, model["overall"])
                      for dow in X_test.index.dayofweek])
    return wrap(preds, X_test.index)


# ══════════════════════════════════════════════════════════════════════════════
# MODEL 3 — Ridge Regression
# ══════════════════════════════════════════════════════════════════════════════

def fit_ridge(X_train, Y_train, alpha=10.0):
    model = Pipeline([
        ("scaler", StandardScaler()),
        ("ridge",  MultiOutputRegressor(Ridge(alpha=alpha), n_jobs=-1))
    ])
    model.fit(X_train.values, Y_train.values)
    return model


def predict_ridge(model, X_test):
    return wrap(model.predict(X_test.values), X_test.index)


# ══════════════════════════════════════════════════════════════════════════════
# MODEL 4 — XGBoost (one per hour)
# ══════════════════════════════════════════════════════════════════════════════

def fit_xgboost(X_train, Y_train, X_val=None, Y_val=None):
    """
    Train one XGBoost regressor per hour of the day (24 total).

    Uses early stopping against the validation set — training
    automatically stops when validation MAE stops improving,
    preventing overfitting without needing to pick n_estimators manually.
    """
    models = {}
    use_es = X_val is not None and Y_val is not None

    for i, hour in enumerate(HOURS):
        params = dict(
            n_estimators         = 500 if use_es else 300,
            max_depth            = 4,
            learning_rate        = 0.05,
            subsample            = 0.8,
            colsample_bytree     = 0.7,
            min_child_weight     = 5,
            reg_alpha            = 0.1,
            reg_lambda           = 1.0,
            n_jobs               = -1,
            random_state         = 42,
            tree_method          = "hist",
            eval_metric          = "mae",
            early_stopping_rounds= 30 if use_es else None,
        )
        model = xgb.XGBRegressor(**params)

        fit_kwargs = {}
        if use_es:
            fit_kwargs["eval_set"] = [
                (X_val.values, Y_val[hour].values)
            ]
            fit_kwargs["verbose"] = False

        model.fit(X_train.values, Y_train[hour].values, **fit_kwargs)
        models[hour] = model

    return models


def predict_xgboost(models, X_test):
    preds = np.column_stack([models[h].predict(X_test.values)
                             for h in HOURS])
    return wrap(preds, X_test.index)


def feature_importance(models, feature_names, top_n=10):
    imp = pd.DataFrame(
        {h: models[h].feature_importances_ for h in HOURS},
        index=feature_names
    ).mean(axis=1).sort_values(ascending=False)
    return imp.head(top_n)


# ══════════════════════════════════════════════════════════════════════════════
# TRAIN ALL METERS
# ══════════════════════════════════════════════════════════════════════════════

def train_one_meter(meter_id: str) -> dict:
    """Train all 4 models for one meter and return metrics dict."""
    print(f"\n{'─'*55}")
    print(f"  Meter: {meter_id}")
    print(f"{'─'*55}")

    X_train = pd.read_csv(f"meter_data/{meter_id}_X_train.csv",
                           index_col=0, parse_dates=True)
    X_test  = pd.read_csv(f"meter_data/{meter_id}_X_test.csv",
                           index_col=0, parse_dates=True)
    Y_train = pd.read_csv(f"meter_data/{meter_id}_Y_train.csv",
                           index_col=0, parse_dates=True)
    Y_test  = pd.read_csv(f"meter_data/{meter_id}_Y_test.csv",
                           index_col=0, parse_dates=True)

    results = {}

    # Persistence
    pred_p = predict_persistence(X_test)
    results["Persistence"] = evaluate(Y_test, pred_p)

    # Mean profile
    mean_model = fit_mean_profile(X_train, Y_train)
    pred_m     = predict_mean_profile(mean_model, X_test)
    results["Mean Profile"] = evaluate(Y_test, pred_m)

    # Ridge
    ridge_model = fit_ridge(X_train, Y_train, alpha=10.0)
    pred_r      = predict_ridge(ridge_model, X_test)
    results["Ridge"] = evaluate(Y_test, pred_r)

    # XGBoost — use last 30 days of training as validation
    val_days   = 30
    X_tr, X_vl = X_train.iloc[:-val_days], X_train.iloc[-val_days:]
    Y_tr, Y_vl = Y_train.iloc[:-val_days], Y_train.iloc[-val_days:]
    print(f"  Training 24 XGBoost models with early stopping...")
    xgb_models = fit_xgboost(X_tr, Y_tr, X_vl, Y_vl)
    pred_x     = predict_xgboost(xgb_models, X_test)
    results["XGBoost"] = evaluate(Y_test, pred_x)

    # Print results table
    print(f"\n  {'Model':<16} {'MAE':>8} {'MAPE':>8} {'Profile r':>10}")
    print(f"  {'─'*44}")
    for name, m in results.items():
        print(f"  {name:<16} {m['mae']:>7.0f}  {m['mape']:>7.2f}%  "
              f"{m['profile_r']:>9.4f}")

    # Feature importance
    print(f"\n  Top 8 features (XGBoost avg across hours):")
    fi = feature_importance(xgb_models, list(X_train.columns), top_n=8)
    for feat, imp in fi.items():
        print(f"    {feat:<30} {imp:.4f}")

    # Save model and predictions
    with open(f"models/{meter_id}_xgb.pkl", "wb") as f:
        pickle.dump(xgb_models, f)
    with open(f"models/{meter_id}_ridge.pkl", "wb") as f:
        pickle.dump(ridge_model, f)

    pred_x.to_csv(f"meter_data/{meter_id}_pred_xgb.csv")
    pred_r.to_csv(f"meter_data/{meter_id}_pred_ridge.csv")
    pred_p.to_csv(f"meter_data/{meter_id}_pred_persist.csv")
    pred_m.to_csv(f"meter_data/{meter_id}_pred_mean.csv")

    return results


# ══════════════════════════════════════════════════════════════════════════════
# MAIN
# ══════════════════════════════════════════════════════════════════════════════

if __name__ == "__main__":
    print("=" * 60)
    print(" UH Mānoa Substation Meters — Step 3: Model Training")
    print("=" * 60)

    meter_ids = pd.read_csv("meter_data/active_meters.csv",
                             header=None)[0].tolist()

    all_results = {}
    for meter_id in meter_ids:
        all_results[meter_id] = train_one_meter(meter_id)

    # ── Cross-meter summary ──────────────────────────────────────────────────
    print(f"\n\n{'='*60}")
    print(" XGBoost Summary — All Meters")
    print(f"{'='*60}")
    print(f"\n  {'Meter':<14} {'MAE':>8} {'MAPE':>8} {'Peak err':>10} {'Profile r':>10}")
    print(f"  {'─'*52}")
    for meter_id, results in all_results.items():
        m = results["XGBoost"]
        print(f"  {meter_id:<14} {m['mae']:>7.0f}  {m['mape']:>7.2f}%  "
              f"{m['peak_err']:>9.0f}  {m['profile_r']:>9.4f}")

    # Save full comparison
    rows = []
    for meter_id, results in all_results.items():
        for model_name, metrics in results.items():
            rows.append({"meter": meter_id, "model": model_name, **metrics})
    pd.DataFrame(rows).to_csv("meter_data/model_comparison_all.csv",
                               index=False)

    print(f"\n── Saved files ─────────────────────────────────────────────")
    print(f"  models/<meter_id>_xgb.pkl          — trained XGBoost models")
    print(f"  meter_data/<meter_id>_pred_*.csv   — test predictions")
    print(f"  meter_data/model_comparison_all.csv — full metrics table")
    print(f"\n  → Run step4_visualize.py next")
